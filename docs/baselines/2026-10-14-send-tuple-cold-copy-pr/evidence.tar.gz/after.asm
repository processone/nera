
/tmp/nera-tuple-publication/after-native/tuple2:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016d33c <_nera_rt_send_tuple>:
10016d33c:     	stp	x28, x27, [sp, #-0x60]!
10016d340:     	stp	x26, x25, [sp, #0x10]
10016d344:     	stp	x24, x23, [sp, #0x20]
10016d348:     	stp	x22, x21, [sp, #0x30]
10016d34c:     	stp	x20, x19, [sp, #0x40]
10016d350:     	stp	x29, x30, [sp, #0x50]
10016d354:     	add	x29, sp, #0x50
10016d358:     	sub	sp, sp, #0x3f0
10016d35c:     	mov	x20, x2
10016d360:     	mov	x24, x0
10016d364:     	stp	x3, x4, [sp, #0x10]
10016d368:     	stp	x5, x6, [sp, #0x20]
10016d36c:     	and	x8, x1, #0x7
10016d370:     	cmp	x8, #0x3
10016d374:     	b.eq	0x10016d390 <_nera_rt_send_tuple+0x54>
10016d378:     	cmp	x8, #0x4
10016d37c:     	b.ne	0x10016d3f0 <_nera_rt_send_tuple+0xb4>
10016d380:     	lsr	x26, x1, #3
10016d384:     	str	x26, [sp, #0x30]
10016d388:     	cbnz	x24, 0x10016d53c <_nera_rt_send_tuple+0x200>
10016d38c:     	b	0x10016d688 <_nera_rt_send_tuple+0x34c>
10016d390:     	lsr	x21, x1, #3
10016d394:     	str	w21, [sp, #0x2c0]
10016d398:     	cbz	x24, 0x10016d3a4 <_nera_rt_send_tuple+0x68>
10016d39c:     	ldr	x8, [x24, #0xb8]
10016d3a0:     	cbnz	x8, 0x10016d3c0 <_nera_rt_send_tuple+0x84>
10016d3a4:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d3a8:     	add	x8, x8, #0x3d8
10016d3ac:     	ldapr	x8, [x8]
10016d3b0:     	cbnz	x8, 0x10016d698 <_nera_rt_send_tuple+0x35c>
10016d3b4:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d3b8:     	ldr	x8, [x8, #0x3e0]
10016d3bc:     	add	x8, x8, #0x10
10016d3c0:     	ldr	x22, [x8, #0x48]
10016d3c4:     	add	x19, x22, #0x10
10016d3c8:     	ldr	x8, [x22, #0x10]
10016d3cc:     	ubfx	x9, x8, #3, #1
10016d3d0:     	cmn	x8, #0x11
10016d3d4:     	csinc	w9, w9, wzr, ls
10016d3d8:     	tbz	w9, #0x0, 0x10016d418 <_nera_rt_send_tuple+0xdc>
10016d3dc:     	add	x0, x22, #0x10
10016d3e0:     	mov	w1, #0x0                ; =0
10016d3e4:     	mov	w3, #-0x1               ; =-1
10016d3e8:     	bl	0x10020de80 <__RNvMs8_NtCsexVl96cpVco_11parking_lot10raw_rwlockNtB5_9RawRwLock16lock_shared_slow>
10016d3ec:     	b	0x10016d42c <_nera_rt_send_tuple+0xf0>
10016d3f0:     	mov	x0, x24
10016d3f4:     	bl	0x10014ce04 <__RNvNtNtCs3JpjsLPrFbG_12nera_runtime3ffi7helpers23capture_exception_trace>
10016d3f8:     	cbz	x24, 0x10016d698 <_nera_rt_send_tuple+0x35c>
10016d3fc:     	mov	w8, #0x3                ; =3
10016d400:     	str	w8, [x24, #0x10]
10016d404:     	mov	w8, #0x33               ; =51
10016d408:     	str	x8, [x24, #0x18]
10016d40c:     	mov	w8, #0x1                ; =1
10016d410:     	str	w8, [x24, #0x3c]
10016d414:     	b	0x10016d698 <_nera_rt_send_tuple+0x35c>
10016d418:     	add	x9, x8, #0x10
10016d41c:     	mov	x10, x8
10016d420:     	casa	x10, x9, [x19]
10016d424:     	cmp	x10, x8
10016d428:     	b.ne	0x10016d3dc <_nera_rt_send_tuple+0xa0>
10016d42c:     	ldr	x8, [x22, #0x30]
10016d430:     	cbz	x8, 0x10016d4c8 <_nera_rt_send_tuple+0x18c>
10016d434:     	ldp	x0, x1, [x22, #0x38]
10016d438:     	add	x2, sp, #0x2c0
10016d43c:     	bl	0x10010483c <__RINvYNtNtNtCs1SSuMAdGM58_3std4hash6random11RandomStateNtNtCsjIpoRzUjyHQ_4core4hash11BuildHasher8hash_oneRmECs3JpjsLPrFbG_12nera_runtime>
10016d440:     	mov	x8, #0x0                ; =0
10016d444:     	lsr	x11, x0, #57
10016d448:     	ldp	x10, x9, [x22, #0x18]
10016d44c:     	dup.8b	v0, w11
10016d450:     	movi.2d	v1, #0xffffffffffffffff
10016d454:     	and	x11, x0, x9
10016d458:     	ldr	d2, [x10, x11]
10016d45c:     	cmeq.8b	v3, v2, v0
10016d460:     	fmov	x12, d3
10016d464:     	ands	x12, x12, #0x8080808080808080
10016d468:     	b.eq	0x10016d498 <_nera_rt_send_tuple+0x15c>
10016d46c:     	rbit	x13, x12
10016d470:     	clz	x13, x13
10016d474:     	add	x13, x11, x13, lsr #3
10016d478:     	and	x13, x13, x9
10016d47c:     	sub	x13, x10, x13, lsl #4
10016d480:     	ldur	w14, [x13, #-0x10]
10016d484:     	cmp	w14, w21
10016d488:     	b.eq	0x10016d50c <_nera_rt_send_tuple+0x1d0>
10016d48c:     	sub	x13, x12, #0x2
10016d490:     	ands	x12, x13, x12
10016d494:     	b.ne	0x10016d46c <_nera_rt_send_tuple+0x130>
10016d498:     	cmeq.8b	v2, v2, v1
10016d49c:     	fmov	x12, d2
10016d4a0:     	cbnz	x12, 0x10016d4c8 <_nera_rt_send_tuple+0x18c>
10016d4a4:     	add	x8, x8, #0x8
10016d4a8:     	add	x0, x11, x8
10016d4ac:     	and	x11, x0, x9
10016d4b0:     	ldr	d2, [x10, x11]
10016d4b4:     	cmeq.8b	v3, v2, v0
10016d4b8:     	fmov	x12, d3
10016d4bc:     	ands	x12, x12, #0x8080808080808080
10016d4c0:     	b.ne	0x10016d46c <_nera_rt_send_tuple+0x130>
10016d4c4:     	b	0x10016d498 <_nera_rt_send_tuple+0x15c>
10016d4c8:     	mov	x0, x24
10016d4cc:     	bl	0x10014ce04 <__RNvNtNtCs3JpjsLPrFbG_12nera_runtime3ffi7helpers23capture_exception_trace>
10016d4d0:     	mov	w21, #0x1               ; =1
10016d4d4:     	cbz	x24, 0x10016d4ec <_nera_rt_send_tuple+0x1b0>
10016d4d8:     	mov	w8, #0x3                ; =3
10016d4dc:     	str	w8, [x24, #0x10]
10016d4e0:     	mov	w8, #0x33               ; =51
10016d4e4:     	str	x8, [x24, #0x18]
10016d4e8:     	str	w21, [x24, #0x3c]
10016d4ec:     	mov	w22, #0x5               ; =5
10016d4f0:     	mov	x8, #-0x10              ; =-16
10016d4f4:     	ldaddl	x8, x8, [x19]
10016d4f8:     	mov	x9, #-0xe               ; =-14
10016d4fc:     	and	x8, x8, x9
10016d500:     	cmp	x8, #0x12
10016d504:     	b.ne	0x10016d52c <_nera_rt_send_tuple+0x1f0>
10016d508:     	b	0x10016e140 <_nera_rt_send_tuple+0xe04>
10016d50c:     	mov	w21, #0x0               ; =0
10016d510:     	ldur	x22, [x13, #-0x8]
10016d514:     	mov	x8, #-0x10              ; =-16
10016d518:     	ldaddl	x8, x8, [x19]
10016d51c:     	mov	x9, #-0xe               ; =-14
10016d520:     	and	x8, x8, x9
10016d524:     	cmp	x8, #0x12
10016d528:     	b.eq	0x10016e140 <_nera_rt_send_tuple+0xe04>
10016d52c:     	cbnz	w21, 0x10016d69c <_nera_rt_send_tuple+0x360>
10016d530:     	str	x22, [sp, #0x30]
10016d534:     	mov	x26, x22
10016d538:     	cbz	x24, 0x10016d688 <_nera_rt_send_tuple+0x34c>
10016d53c:     	ldr	x8, [x24]
10016d540:     	cmp	x8, x26
10016d544:     	b.ne	0x10016d680 <_nera_rt_send_tuple+0x344>
10016d548:     	ldr	x21, [x24, #0x28]
10016d54c:     	mov	w22, #0x5               ; =5
10016d550:     	cbz	x21, 0x10016d69c <_nera_rt_send_tuple+0x360>
10016d554:     	ldr	x19, [x24, #0x30]
10016d558:     	cbz	x19, 0x10016d69c <_nera_rt_send_tuple+0x360>
10016d55c:     	cmp	x20, #0x5
10016d560:     	b.hs	0x10016e178 <_nera_rt_send_tuple+0xe3c>
10016d564:     	lsl	x23, x20, #3
10016d568:     	cbz	x20, 0x10016d5d4 <_nera_rt_send_tuple+0x298>
10016d56c:     	ldr	x8, [sp, #0x10]
10016d570:     	and	x9, x8, #0x7
10016d574:     	sub	x10, x9, #0x2
10016d578:     	cmp	x10, #0x4
10016d57c:     	b.hs	0x10016db68 <_nera_rt_send_tuple+0x82c>
10016d580:     	cmp	x20, #0x1
10016d584:     	b.eq	0x10016d5d4 <_nera_rt_send_tuple+0x298>
10016d588:     	ldr	x8, [sp, #0x18]
10016d58c:     	and	x9, x8, #0x7
10016d590:     	sub	x10, x9, #0x2
10016d594:     	cmp	x10, #0x4
10016d598:     	b.hs	0x10016dc30 <_nera_rt_send_tuple+0x8f4>
10016d59c:     	cmp	x20, #0x2
10016d5a0:     	b.eq	0x10016d5d4 <_nera_rt_send_tuple+0x298>
10016d5a4:     	ldr	x8, [sp, #0x20]
10016d5a8:     	and	x9, x8, #0x7
10016d5ac:     	sub	x10, x9, #0x2
10016d5b0:     	cmp	x10, #0x4
10016d5b4:     	b.hs	0x10016dea0 <_nera_rt_send_tuple+0xb64>
10016d5b8:     	cmp	x20, #0x3
10016d5bc:     	b.eq	0x10016d5d4 <_nera_rt_send_tuple+0x298>
10016d5c0:     	ldr	x8, [sp, #0x28]
10016d5c4:     	and	x9, x8, #0x7
10016d5c8:     	sub	x10, x9, #0x2
10016d5cc:     	cmp	x10, #0x4
10016d5d0:     	b.hs	0x10016e06c <_nera_rt_send_tuple+0xd30>
10016d5d4:     	add	x24, x20, #0x1
10016d5d8:     	ldr	x9, [x21]
10016d5dc:     	ldr	x8, [x21, #0x18]
10016d5e0:     	sub	x9, x9, x8
10016d5e4:     	cmp	x20, x9
10016d5e8:     	b.hs	0x10016e274 <_nera_rt_send_tuple+0xf38>
10016d5ec:     	ldr	x9, [x21, #0x8]
10016d5f0:     	add	x22, x9, x8, lsl #3
10016d5f4:     	add	x8, x8, x24
10016d5f8:     	str	x8, [x21, #0x18]
10016d5fc:     	ldr	x8, [x21, #0xd0]
10016d600:     	add	x8, x8, x24, lsl #3
10016d604:     	str	x8, [x21, #0xd0]
10016d608:     	lsl	x8, x20, #4
10016d60c:     	str	x8, [x22]
10016d610:     	cbz	x20, 0x10016e0d8 <_nera_rt_send_tuple+0xd9c>
10016d614:     	add	x20, x22, #0x8
10016d618:     	add	x24, sp, #0x10
10016d61c:     	mov	w25, #0x1               ; =1
10016d620:     	b	0x10016d630 <_nera_rt_send_tuple+0x2f4>
10016d624:     	str	x0, [x20], #0x8
10016d628:     	subs	x23, x23, #0x8
10016d62c:     	b.eq	0x10016e0d8 <_nera_rt_send_tuple+0xd9c>
10016d630:     	ldr	x8, [x24], #0x8
10016d634:     	and	x0, x8, #0x7fffffffffffffff
10016d638:     	and	x8, x8, #0x7
10016d63c:     	sub	x9, x8, #0x2
10016d640:     	cmp	x9, #0x4
10016d644:     	b.lo	0x10016d624 <_nera_rt_send_tuple+0x2e8>
10016d648:     	cmp	x8, #0x0
10016d64c:     	ccmp	x0, #0x0, #0x4, eq
10016d650:     	b.eq	0x10016e0e8 <_nera_rt_send_tuple+0xdac>
10016d654:     	ldp	x8, x9, [x0]
10016d658:     	ldr	x2, [x0, #0x10]
10016d65c:     	sub	x1, x9, #0x10
10016d660:     	ldadd	x25, x9, [x1]
10016d664:     	tbnz	x9, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016d668:     	tst	x8, #0x70
10016d66c:     	lsr	x8, x8, #7
10016d670:     	cinc	x3, x8, ne
10016d674:     	mov	x0, x21
10016d678:     	bl	0x10011c340 <__RNvMs3_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB5_11ProcessHeap26alloc_refc_binary_from_arc>
10016d67c:     	b	0x10016d624 <_nera_rt_send_tuple+0x2e8>
10016d680:     	ldr	x27, [x24, #0xb8]
10016d684:     	cbnz	x27, 0x10016d6cc <_nera_rt_send_tuple+0x390>
10016d688:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d68c:     	add	x8, x8, #0x3d8
10016d690:     	ldapr	x8, [x8]
10016d694:     	cbz	x8, 0x10016d6c0 <_nera_rt_send_tuple+0x384>
10016d698:     	mov	w22, #0x5               ; =5
10016d69c:     	mov	x0, x22
10016d6a0:     	add	sp, sp, #0x3f0
10016d6a4:     	ldp	x29, x30, [sp, #0x50]
10016d6a8:     	ldp	x20, x19, [sp, #0x40]
10016d6ac:     	ldp	x22, x21, [sp, #0x30]
10016d6b0:     	ldp	x24, x23, [sp, #0x20]
10016d6b4:     	ldp	x26, x25, [sp, #0x10]
10016d6b8:     	ldp	x28, x27, [sp], #0x60
10016d6bc:     	ret
10016d6c0:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d6c4:     	ldr	x8, [x8, #0x3e0]
10016d6c8:     	add	x27, x8, #0x10
10016d6cc:     	adrp	x0, 0x10026e000 <__rjem_je_tsd_boot_wrapper+0x608>
10016d6d0:     	add	x0, x0, #0xf30
10016d6d4:     	ldr	x8, [x0]
10016d6d8:     	blr	x8
10016d6dc:     	mov	x22, x0
10016d6e0:     	ldrb	w8, [x0, #0x18]
10016d6e4:     	cbnz	w8, 0x10016e194 <_nera_rt_send_tuple+0xe58>
10016d6e8:     	ldr	x8, [x22]
10016d6ec:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10016d6f0:     	cmp	x8, x9
10016d6f4:     	b.hs	0x10016e1c0 <_nera_rt_send_tuple+0xe84>
10016d6f8:     	add	x9, x8, #0x1
10016d6fc:     	str	x9, [x22]
10016d700:     	mov	x25, x22
10016d704:     	ldr	x9, [x25, #0x10]!
10016d708:     	ldr	x10, [x22, #0x8]
10016d70c:     	cmp	x9, #0x0
10016d710:     	ccmp	x10, x26, #0x0, ne
10016d714:     	b.eq	0x10016d7cc <_nera_rt_send_tuple+0x490>
10016d718:     	str	x8, [x22]
10016d71c:     	ldr	x8, [x27, #0x28]
10016d720:     	add	x0, sp, #0x2c0
10016d724:     	add	x1, x8, #0x10
10016d728:     	add	x2, sp, #0x30
10016d72c:     	bl	0x100103c2c <__RINvXs2_CsaEawCaY6Xdf_7dashmapINtB6_7DashMapyINtNtCs6zY7rJBZy9D_5alloc4sync3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryEEINtNtB6_1t3MapyBH_NtNtNtCs1SSuMAdGM58_3std4hash6random11RandomStateE4__getyEB1j_>
10016d730:     	ldr	x0, [sp, #0x2c0]
10016d734:     	cbz	x0, 0x10016d7f4 <_nera_rt_send_tuple+0x4b8>
10016d738:     	ldr	x8, [sp, #0x2d0]
10016d73c:     	ldr	x9, [x8]
10016d740:     	mov	w10, #0x1               ; =1
10016d744:     	ldadd	x10, x9, [x9]
10016d748:     	tbnz	x9, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016d74c:     	ldr	x19, [x8]
10016d750:     	mov	x8, #-0x4               ; =-4
10016d754:     	ldaddl	x8, x8, [x0]
10016d758:     	cmp	x8, #0x6
10016d75c:     	b.eq	0x10016e258 <_nera_rt_send_tuple+0xf1c>
10016d760:     	str	x19, [sp, #0x1a0]
10016d764:     	ldrb	w8, [x22, #0x18]
10016d768:     	cbnz	w8, 0x10016e2a0 <_nera_rt_send_tuple+0xf64>
10016d76c:     	mov	w8, #0x1                ; =1
10016d770:     	ldadd	x8, x8, [x19]
10016d774:     	tbnz	x8, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016d778:     	str	x26, [sp, #0x2c0]
10016d77c:     	str	x19, [sp, #0x2c8]
10016d780:     	ldr	x8, [x22]
10016d784:     	cbnz	x8, 0x10016e260 <_nera_rt_send_tuple+0xf24>
10016d788:     	mov	x8, #-0x1               ; =-1
10016d78c:     	str	x8, [x22]
10016d790:     	ldr	x9, [x22, #0x10]
10016d794:     	cbz	x9, 0x10016d7b0 <_nera_rt_send_tuple+0x474>
10016d798:     	ldaddl	x8, x8, [x9]
10016d79c:     	cmp	x8, #0x1
10016d7a0:     	b.ne	0x10016d7b0 <_nera_rt_send_tuple+0x474>
10016d7a4:     	dmb	ishld
10016d7a8:     	mov	x0, x25
10016d7ac:     	bl	0x100125b40 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016d7b0:     	stp	x26, x19, [x22, #0x8]
10016d7b4:     	ldr	x8, [x22]
10016d7b8:     	add	x8, x8, #0x1
10016d7bc:     	str	x8, [x22]
10016d7c0:     	str	x19, [sp, #0x38]
10016d7c4:     	cbnz	x24, 0x10016d800 <_nera_rt_send_tuple+0x4c4>
10016d7c8:     	b	0x10016d870 <_nera_rt_send_tuple+0x534>
10016d7cc:     	mov	w8, #0x1                ; =1
10016d7d0:     	ldadd	x8, x8, [x9]
10016d7d4:     	tbnz	x8, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016d7d8:     	ldr	x19, [x22, #0x10]
10016d7dc:     	ldr	x8, [x22]
10016d7e0:     	sub	x8, x8, #0x1
10016d7e4:     	str	x8, [x22]
10016d7e8:     	str	x19, [sp, #0x38]
10016d7ec:     	cbnz	x24, 0x10016d800 <_nera_rt_send_tuple+0x4c4>
10016d7f0:     	b	0x10016d870 <_nera_rt_send_tuple+0x534>
10016d7f4:     	mov	x19, #0x0               ; =0
10016d7f8:     	str	x19, [sp, #0x38]
10016d7fc:     	cbz	x24, 0x10016d870 <_nera_rt_send_tuple+0x534>
10016d800:     	ldr	x24, [x24, #0x28]
10016d804:     	cbz	x24, 0x10016d870 <_nera_rt_send_tuple+0x534>
10016d808:     	add	x21, x20, #0x1
10016d80c:     	ldr	x9, [x24]
10016d810:     	ldr	x8, [x24, #0x18]
10016d814:     	sub	x9, x9, x8
10016d818:     	cmp	x21, x9
10016d81c:     	b.hi	0x10016e1ec <_nera_rt_send_tuple+0xeb0>
10016d820:     	ldr	x9, [x24, #0x8]
10016d824:     	add	x22, x9, x8, lsl #3
10016d828:     	add	x8, x8, x21
10016d82c:     	str	x8, [x24, #0x18]
10016d830:     	ldr	x8, [x24, #0xd0]
10016d834:     	add	x8, x8, x21, lsl #3
10016d838:     	str	x8, [x24, #0xd0]
10016d83c:     	lsr	x8, x20, #60
10016d840:     	cbnz	x8, 0x10016e210 <_nera_rt_send_tuple+0xed4>
10016d844:     	lsl	x8, x20, #4
10016d848:     	str	x8, [x22]
10016d84c:     	cmp	x20, #0x5
10016d850:     	b.hs	0x10016e22c <_nera_rt_send_tuple+0xef0>
10016d854:     	cbz	x20, 0x10016d868 <_nera_rt_send_tuple+0x52c>
10016d858:     	lsl	x2, x20, #3
10016d85c:     	add	x0, x22, #0x8
10016d860:     	add	x1, sp, #0x10
10016d864:     	bl	0x100215254 <_writev+0x100215254>
10016d868:     	cbnz	x19, 0x10016d878 <_nera_rt_send_tuple+0x53c>
10016d86c:     	b	0x10016d69c <_nera_rt_send_tuple+0x360>
10016d870:     	mov	w22, #0x5               ; =5
10016d874:     	cbz	x19, 0x10016d69c <_nera_rt_send_tuple+0x360>
10016d878:     	str	x19, [sp, #0x40]
10016d87c:     	add	x8, x19, #0x5a0
10016d880:     	ldapr	w8, [x8]
10016d884:     	tst	w8, #0xfffffffd
10016d888:     	b.ne	0x10016d9dc <_nera_rt_send_tuple+0x6a0>
10016d88c:     	add	x25, x19, #0x180
10016d890:     	ldrb	w8, [x19, #0x180]
10016d894:     	tbnz	w8, #0x0, 0x10016d9dc <_nera_rt_send_tuple+0x6a0>
10016d898:     	orr	w9, w8, #0x1
10016d89c:     	mov	x10, x8
10016d8a0:     	casab	w10, w9, [x25]
10016d8a4:     	cmp	w10, w8, uxtb
10016d8a8:     	mov	x8, x10
10016d8ac:     	b.ne	0x10016d894 <_nera_rt_send_tuple+0x558>
10016d8b0:     	cmp	x20, #0x5
10016d8b4:     	b.hs	0x10016e1d0 <_nera_rt_send_tuple+0xe94>
10016d8b8:     	cbz	x20, 0x10016d924 <_nera_rt_send_tuple+0x5e8>
10016d8bc:     	ldr	x8, [sp, #0x10]
10016d8c0:     	and	x9, x8, #0x7
10016d8c4:     	sub	x10, x9, #0x2
10016d8c8:     	cmp	x10, #0x4
10016d8cc:     	b.hs	0x10016dbe8 <_nera_rt_send_tuple+0x8ac>
10016d8d0:     	cmp	x20, #0x1
10016d8d4:     	b.eq	0x10016d924 <_nera_rt_send_tuple+0x5e8>
10016d8d8:     	ldr	x8, [sp, #0x18]
10016d8dc:     	and	x9, x8, #0x7
10016d8e0:     	sub	x10, x9, #0x2
10016d8e4:     	cmp	x10, #0x4
10016d8e8:     	b.hs	0x10016dc54 <_nera_rt_send_tuple+0x918>
10016d8ec:     	cmp	x20, #0x2
10016d8f0:     	b.eq	0x10016d924 <_nera_rt_send_tuple+0x5e8>
10016d8f4:     	ldr	x8, [sp, #0x20]
10016d8f8:     	and	x9, x8, #0x7
10016d8fc:     	sub	x10, x9, #0x2
10016d900:     	cmp	x10, #0x4
10016d904:     	b.hs	0x10016df0c <_nera_rt_send_tuple+0xbd0>
10016d908:     	cmp	x20, #0x3
10016d90c:     	b.eq	0x10016d924 <_nera_rt_send_tuple+0x5e8>
10016d910:     	ldr	x8, [sp, #0x28]
10016d914:     	and	x9, x8, #0x7
10016d918:     	sub	x10, x9, #0x2
10016d91c:     	cmp	x10, #0x4
10016d920:     	b.hs	0x10016e0f8 <_nera_rt_send_tuple+0xdbc>
10016d924:     	add	x21, x20, #0x1
10016d928:     	ldr	x9, [x19, #0x280]
10016d92c:     	ldr	x8, [x19, #0x298]
10016d930:     	sub	x9, x9, x8
10016d934:     	cmp	x20, x9
10016d938:     	str	x27, [sp, #0x8]
10016d93c:     	b.hs	0x10016e2b8 <_nera_rt_send_tuple+0xf7c>
10016d940:     	mov	x23, x26
10016d944:     	ldr	x9, [x19, #0x288]
10016d948:     	add	x24, x9, x8, lsl #3
10016d94c:     	add	x8, x8, x21
10016d950:     	str	x8, [x19, #0x298]
10016d954:     	ldr	x8, [x19, #0x350]
10016d958:     	add	x8, x8, x21, lsl #3
10016d95c:     	str	x8, [x19, #0x350]
10016d960:     	lsl	x8, x20, #4
10016d964:     	str	x8, [x24]
10016d968:     	cbz	x20, 0x10016e2e4 <_nera_rt_send_tuple+0xfa8>
10016d96c:     	lsl	x20, x20, #3
10016d970:     	add	x26, x24, #0x8
10016d974:     	add	x27, sp, #0x10
10016d978:     	mov	w28, #0x1               ; =1
10016d97c:     	b	0x10016d98c <_nera_rt_send_tuple+0x650>
10016d980:     	str	x0, [x26], #0x8
10016d984:     	subs	x20, x20, #0x8
10016d988:     	b.eq	0x10016e2e4 <_nera_rt_send_tuple+0xfa8>
10016d98c:     	ldr	x8, [x27], #0x8
10016d990:     	and	x0, x8, #0x7fffffffffffffff
10016d994:     	and	x8, x8, #0x7
10016d998:     	sub	x9, x8, #0x2
10016d99c:     	cmp	x9, #0x4
10016d9a0:     	b.lo	0x10016d980 <_nera_rt_send_tuple+0x644>
10016d9a4:     	cmp	x8, #0x0
10016d9a8:     	ccmp	x0, #0x0, #0x4, eq
10016d9ac:     	b.eq	0x10016e130 <_nera_rt_send_tuple+0xdf4>
10016d9b0:     	ldp	x8, x9, [x0]
10016d9b4:     	ldr	x2, [x0, #0x10]
10016d9b8:     	sub	x1, x9, #0x10
10016d9bc:     	ldadd	x28, x9, [x1]
10016d9c0:     	tbnz	x9, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016d9c4:     	tst	x8, #0x70
10016d9c8:     	lsr	x8, x8, #7
10016d9cc:     	cinc	x3, x8, ne
10016d9d0:     	add	x0, x19, #0x280
10016d9d4:     	bl	0x10011c340 <__RNvMs3_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB5_11ProcessHeap26alloc_refc_binary_from_arc>
10016d9d8:     	b	0x10016d980 <_nera_rt_send_tuple+0x644>
10016d9dc:     	cmp	x20, #0x5
10016d9e0:     	b.hs	0x10016e15c <_nera_rt_send_tuple+0xe20>
10016d9e4:     	cbz	x20, 0x10016db0c <_nera_rt_send_tuple+0x7d0>
10016d9e8:     	ldr	x8, [sp, #0x10]
10016d9ec:     	and	x9, x8, #0x7
10016d9f0:     	sub	x10, x9, #0x2
10016d9f4:     	cmp	x10, #0x4
10016d9f8:     	b.hs	0x10016db44 <_nera_rt_send_tuple+0x808>
10016d9fc:     	cmp	x20, #0x1
10016da00:     	b.eq	0x10016da50 <_nera_rt_send_tuple+0x714>
10016da04:     	ldr	x8, [sp, #0x18]
10016da08:     	and	x9, x8, #0x7
10016da0c:     	sub	x10, x9, #0x2
10016da10:     	cmp	x10, #0x4
10016da14:     	b.hs	0x10016dc0c <_nera_rt_send_tuple+0x8d0>
10016da18:     	cmp	x20, #0x2
10016da1c:     	b.eq	0x10016da50 <_nera_rt_send_tuple+0x714>
10016da20:     	ldr	x8, [sp, #0x20]
10016da24:     	and	x9, x8, #0x7
10016da28:     	sub	x10, x9, #0x2
10016da2c:     	cmp	x10, #0x4
10016da30:     	b.hs	0x10016de7c <_nera_rt_send_tuple+0xb40>
10016da34:     	cmp	x20, #0x3
10016da38:     	b.eq	0x10016da50 <_nera_rt_send_tuple+0x714>
10016da3c:     	ldr	x8, [sp, #0x28]
10016da40:     	and	x9, x8, #0x7
10016da44:     	sub	x10, x9, #0x2
10016da48:     	cmp	x10, #0x4
10016da4c:     	b.hs	0x10016df30 <_nera_rt_send_tuple+0xbf4>
10016da50:     	cmp	x20, #0x3
10016da54:     	b.hs	0x10016db8c <_nera_rt_send_tuple+0x850>
10016da58:     	stp	x26, x27, [sp]
10016da5c:     	mov	w8, #0x5                ; =5
10016da60:     	str	xzr, [sp, #0x2c0]
10016da64:     	str	x8, [sp, #0x2c8]
10016da68:     	add	x24, sp, #0x2c0
10016da6c:     	str	xzr, [sp, #0x2d8]
10016da70:     	str	x8, [sp, #0x2e0]
10016da74:     	add	x25, sp, #0x10
10016da78:     	mov	x26, #-0x1              ; =-1
10016da7c:     	mov	x28, x20
10016da80:     	b	0x10016da98 <_nera_rt_send_tuple+0x75c>
10016da84:     	stp	x21, x23, [x24]
10016da88:     	str	x27, [x24, #0x10]
10016da8c:     	add	x24, x24, #0x18
10016da90:     	subs	x28, x28, #0x1
10016da94:     	b.eq	0x10016db24 <_nera_rt_send_tuple+0x7e8>
10016da98:     	ldr	x8, [x25], #0x8
10016da9c:     	and	x23, x8, #0x7fffffffffffffff
10016daa0:     	and	x8, x8, #0x7
10016daa4:     	sub	x9, x8, #0x2
10016daa8:     	cmp	x9, #0x4
10016daac:     	b.hs	0x10016dad8 <_nera_rt_send_tuple+0x79c>
10016dab0:     	mov	x21, #0x0               ; =0
10016dab4:     	ldr	x8, [x24]
10016dab8:     	cbz	x8, 0x10016da84 <_nera_rt_send_tuple+0x748>
10016dabc:     	ldaddl	x26, x8, [x8]
10016dac0:     	cmp	x8, #0x1
10016dac4:     	b.ne	0x10016da84 <_nera_rt_send_tuple+0x748>
10016dac8:     	dmb	ishld
10016dacc:     	mov	x0, x24
10016dad0:     	bl	0x1001259b8 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime6binary10BinaryDataE9drop_slowBK_>
10016dad4:     	b	0x10016da84 <_nera_rt_send_tuple+0x748>
10016dad8:     	cmp	x8, #0x0
10016dadc:     	ccmp	x23, #0x0, #0x4, eq
10016dae0:     	b.eq	0x10016e14c <_nera_rt_send_tuple+0xe10>
10016dae4:     	ldp	x8, x9, [x23]
10016dae8:     	lsr	x10, x8, #7
10016daec:     	tst	x8, #0x70
10016daf0:     	cinc	x27, x10, ne
10016daf4:     	ldr	x23, [x23, #0x10]
10016daf8:     	sub	x21, x9, #0x10
10016dafc:     	mov	w8, #0x1                ; =1
10016db00:     	ldadd	x8, x8, [x21]
10016db04:     	tbz	x8, #0x3f, 0x10016dab4 <_nera_rt_send_tuple+0x778>
10016db08:     	brk	#0x1
10016db0c:     	stp	x26, x27, [sp]
10016db10:     	mov	w8, #0x5                ; =5
10016db14:     	str	xzr, [sp, #0x2c0]
10016db18:     	str	x8, [sp, #0x2c8]
10016db1c:     	str	xzr, [sp, #0x2d8]
10016db20:     	str	x8, [sp, #0x2e0]
10016db24:     	ldp	q0, q1, [sp, #0x2c0]
10016db28:     	stp	q0, q1, [sp, #0x50]
10016db2c:     	ldr	q0, [sp, #0x2e0]
10016db30:     	stur	q0, [sp, #0x70]
10016db34:     	mov	w8, #0x4                ; =4
10016db38:     	stp	w8, w20, [sp, #0x48]
10016db3c:     	ldp	x26, x27, [sp]
10016db40:     	b	0x10016e01c <_nera_rt_send_tuple+0xce0>
10016db44:     	cbnz	x9, 0x10016df50 <_nera_rt_send_tuple+0xc14>
10016db48:     	tst	x8, #0x7fffffffffffffff
10016db4c:     	b.eq	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016db50:     	and	x8, x8, #0x7ffffffffffffff8
10016db54:     	ldr	x8, [x8]
10016db58:     	and	x8, x8, #0xf
10016db5c:     	cmp	x8, #0x6
10016db60:     	b.eq	0x10016d9fc <_nera_rt_send_tuple+0x6c0>
10016db64:     	b	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016db68:     	cbnz	x9, 0x10016e08c <_nera_rt_send_tuple+0xd50>
10016db6c:     	tst	x8, #0x7fffffffffffffff
10016db70:     	b.eq	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016db74:     	and	x8, x8, #0x7ffffffffffffff8
10016db78:     	ldr	x8, [x8]
10016db7c:     	and	x8, x8, #0xf
10016db80:     	cmp	x8, #0x6
10016db84:     	b.eq	0x10016d580 <_nera_rt_send_tuple+0x244>
10016db88:     	b	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016db8c:     	add	x8, x20, x20, lsl #1
10016db90:     	lsl	x24, x8, #3
10016db94:     	bl	0x100174620 <__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10016db98:     	mov	x0, x24
10016db9c:     	bl	0x100176fd0 <__rjem_malloc>
10016dba0:     	cbz	x0, 0x10016e3e8 <_nera_rt_send_tuple+0x10ac>
10016dba4:     	stp	x20, x0, [sp, #0x1a0]
10016dba8:     	str	xzr, [sp, #0x1b0]
10016dbac:     	ldr	x9, [sp, #0x10]
10016dbb0:     	and	x8, x9, #0x7fffffffffffffff
10016dbb4:     	and	x9, x9, #0x7
10016dbb8:     	sub	x10, x9, #0x2
10016dbbc:     	cmp	x10, #0x4
10016dbc0:     	b.hs	0x10016dc78 <_nera_rt_send_tuple+0x93c>
10016dbc4:     	mov	x24, #0x0               ; =0
10016dbc8:     	str	x8, [sp, #0x2c8]
10016dbcc:     	str	xzr, [sp, #0x2c0]
10016dbd0:     	ldr	x8, [sp, #0x1a0]
10016dbd4:     	cbnz	x8, 0x10016dcb8 <_nera_rt_send_tuple+0x97c>
10016dbd8:     	add	x0, sp, #0x1a0
10016dbdc:     	bl	0x1001fafec <__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecTjjjEE8grow_oneCs3JpjsLPrFbG_12nera_runtime>
10016dbe0:     	ldr	x0, [sp, #0x1a8]
10016dbe4:     	b	0x10016dcb8 <_nera_rt_send_tuple+0x97c>
10016dbe8:     	cbnz	x9, 0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dbec:     	tst	x8, #0x7fffffffffffffff
10016dbf0:     	b.eq	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dbf4:     	and	x8, x8, #0x7ffffffffffffff8
10016dbf8:     	ldr	x8, [x8]
10016dbfc:     	and	x8, x8, #0xf
10016dc00:     	cmp	x8, #0x6
10016dc04:     	b.eq	0x10016d8d0 <_nera_rt_send_tuple+0x594>
10016dc08:     	b	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dc0c:     	cbnz	x9, 0x10016df50 <_nera_rt_send_tuple+0xc14>
10016dc10:     	tst	x8, #0x7fffffffffffffff
10016dc14:     	b.eq	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016dc18:     	and	x8, x8, #0x7ffffffffffffff8
10016dc1c:     	ldr	x8, [x8]
10016dc20:     	and	x8, x8, #0xf
10016dc24:     	cmp	x8, #0x6
10016dc28:     	b.eq	0x10016da18 <_nera_rt_send_tuple+0x6dc>
10016dc2c:     	b	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016dc30:     	cbnz	x9, 0x10016e08c <_nera_rt_send_tuple+0xd50>
10016dc34:     	tst	x8, #0x7fffffffffffffff
10016dc38:     	b.eq	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016dc3c:     	and	x8, x8, #0x7ffffffffffffff8
10016dc40:     	ldr	x8, [x8]
10016dc44:     	and	x8, x8, #0xf
10016dc48:     	cmp	x8, #0x6
10016dc4c:     	b.eq	0x10016d59c <_nera_rt_send_tuple+0x260>
10016dc50:     	b	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016dc54:     	cbnz	x9, 0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dc58:     	tst	x8, #0x7fffffffffffffff
10016dc5c:     	b.eq	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dc60:     	and	x8, x8, #0x7ffffffffffffff8
10016dc64:     	ldr	x8, [x8]
10016dc68:     	and	x8, x8, #0xf
10016dc6c:     	cmp	x8, #0x6
10016dc70:     	b.eq	0x10016d8ec <_nera_rt_send_tuple+0x5b0>
10016dc74:     	b	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016dc78:     	cbnz	x9, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016dc7c:     	cbz	x8, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016dc80:     	ldp	x9, x10, [x8]
10016dc84:     	ldr	x8, [x8, #0x10]
10016dc88:     	sub	x24, x10, #0x10
10016dc8c:     	mov	w10, #0x1               ; =1
10016dc90:     	ldadd	x10, x10, [x24]
10016dc94:     	tbnz	x10, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016dc98:     	tst	x9, #0x70
10016dc9c:     	lsr	x9, x9, #7
10016dca0:     	cinc	x9, x9, ne
10016dca4:     	str	x24, [sp, #0x2c0]
10016dca8:     	str	x8, [sp, #0x2c8]
10016dcac:     	str	x9, [sp, #0x2d0]
10016dcb0:     	ldr	x8, [sp, #0x1a0]
10016dcb4:     	cbz	x8, 0x10016dbd8 <_nera_rt_send_tuple+0x89c>
10016dcb8:     	ldr	q0, [sp, #0x2c0]
10016dcbc:     	str	q0, [x0]
10016dcc0:     	ldr	x8, [sp, #0x2d0]
10016dcc4:     	str	x8, [x0, #0x10]
10016dcc8:     	mov	w8, #0x1                ; =1
10016dccc:     	str	x8, [sp, #0x1b0]
10016dcd0:     	ldr	x9, [sp, #0x18]
10016dcd4:     	and	x8, x9, #0x7fffffffffffffff
10016dcd8:     	and	x9, x9, #0x7
10016dcdc:     	sub	x10, x9, #0x2
10016dce0:     	cmp	x10, #0x4
10016dce4:     	b.hs	0x10016ddec <_nera_rt_send_tuple+0xab0>
10016dce8:     	mov	x24, #0x0               ; =0
10016dcec:     	str	x8, [sp, #0x2c8]
10016dcf0:     	str	xzr, [sp, #0x2c0]
10016dcf4:     	ldr	x8, [sp, #0x1a0]
10016dcf8:     	cmp	x8, #0x1
10016dcfc:     	b.ne	0x10016dd0c <_nera_rt_send_tuple+0x9d0>
10016dd00:     	add	x0, sp, #0x1a0
10016dd04:     	bl	0x1001fafec <__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecTjjjEE8grow_oneCs3JpjsLPrFbG_12nera_runtime>
10016dd08:     	ldr	x0, [sp, #0x1a8]
10016dd0c:     	ldr	q0, [sp, #0x2c0]
10016dd10:     	stur	q0, [x0, #0x18]
10016dd14:     	ldr	x8, [sp, #0x2d0]
10016dd18:     	str	x8, [x0, #0x28]
10016dd1c:     	mov	w8, #0x2                ; =2
10016dd20:     	str	x8, [sp, #0x1b0]
10016dd24:     	ldr	x9, [sp, #0x20]
10016dd28:     	and	x8, x9, #0x7fffffffffffffff
10016dd2c:     	and	x9, x9, #0x7
10016dd30:     	sub	x10, x9, #0x2
10016dd34:     	cmp	x10, #0x4
10016dd38:     	b.hs	0x10016de34 <_nera_rt_send_tuple+0xaf8>
10016dd3c:     	mov	x24, #0x0               ; =0
10016dd40:     	str	x8, [sp, #0x2c8]
10016dd44:     	str	xzr, [sp, #0x2c0]
10016dd48:     	ldr	x8, [sp, #0x1a0]
10016dd4c:     	cmp	x8, #0x2
10016dd50:     	b.ne	0x10016dd60 <_nera_rt_send_tuple+0xa24>
10016dd54:     	add	x0, sp, #0x1a0
10016dd58:     	bl	0x1001fafec <__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecTjjjEE8grow_oneCs3JpjsLPrFbG_12nera_runtime>
10016dd5c:     	ldr	x0, [sp, #0x1a8]
10016dd60:     	ldr	q0, [sp, #0x2c0]
10016dd64:     	str	q0, [x0, #0x30]
10016dd68:     	ldr	x8, [sp, #0x2d0]
10016dd6c:     	str	x8, [x0, #0x40]
10016dd70:     	mov	w25, #0x3               ; =3
10016dd74:     	str	x25, [sp, #0x1b0]
10016dd78:     	cmp	x20, #0x3
10016dd7c:     	b.eq	0x10016ddd4 <_nera_rt_send_tuple+0xa98>
10016dd80:     	ldr	x9, [sp, #0x28]
10016dd84:     	and	x8, x9, #0x7fffffffffffffff
10016dd88:     	and	x9, x9, #0x7
10016dd8c:     	sub	x10, x9, #0x2
10016dd90:     	cmp	x10, #0x4
10016dd94:     	b.hs	0x10016dec4 <_nera_rt_send_tuple+0xb88>
10016dd98:     	mov	x24, #0x0               ; =0
10016dd9c:     	str	x8, [sp, #0x2c8]
10016dda0:     	str	xzr, [sp, #0x2c0]
10016dda4:     	ldr	x8, [sp, #0x1a0]
10016dda8:     	cmp	x8, #0x3
10016ddac:     	b.ne	0x10016ddbc <_nera_rt_send_tuple+0xa80>
10016ddb0:     	add	x0, sp, #0x1a0
10016ddb4:     	bl	0x1001fafec <__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecTjjjEE8grow_oneCs3JpjsLPrFbG_12nera_runtime>
10016ddb8:     	ldr	x0, [sp, #0x1a8]
10016ddbc:     	ldr	q0, [sp, #0x2c0]
10016ddc0:     	stur	q0, [x0, #0x48]
10016ddc4:     	ldr	x8, [sp, #0x2d0]
10016ddc8:     	str	x8, [x0, #0x58]
10016ddcc:     	mov	w8, #0x4                ; =4
10016ddd0:     	str	x8, [sp, #0x1b0]
10016ddd4:     	ldr	q0, [sp, #0x1a0]
10016ddd8:     	stur	q0, [sp, #0x50]
10016dddc:     	ldr	x8, [sp, #0x1b0]
10016dde0:     	str	x8, [sp, #0x60]
10016dde4:     	str	w25, [sp, #0x48]
10016dde8:     	b	0x10016e01c <_nera_rt_send_tuple+0xce0>
10016ddec:     	cbnz	x9, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016ddf0:     	cbz	x8, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016ddf4:     	ldp	x9, x10, [x8]
10016ddf8:     	ldr	x8, [x8, #0x10]
10016ddfc:     	sub	x24, x10, #0x10
10016de00:     	mov	w10, #0x1               ; =1
10016de04:     	ldadd	x10, x10, [x24]
10016de08:     	tbnz	x10, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016de0c:     	tst	x9, #0x70
10016de10:     	lsr	x9, x9, #7
10016de14:     	cinc	x9, x9, ne
10016de18:     	str	x24, [sp, #0x2c0]
10016de1c:     	str	x8, [sp, #0x2c8]
10016de20:     	str	x9, [sp, #0x2d0]
10016de24:     	ldr	x8, [sp, #0x1a0]
10016de28:     	cmp	x8, #0x1
10016de2c:     	b.eq	0x10016dd00 <_nera_rt_send_tuple+0x9c4>
10016de30:     	b	0x10016dd0c <_nera_rt_send_tuple+0x9d0>
10016de34:     	cbnz	x9, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016de38:     	cbz	x8, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016de3c:     	ldp	x9, x10, [x8]
10016de40:     	ldr	x8, [x8, #0x10]
10016de44:     	sub	x24, x10, #0x10
10016de48:     	mov	w10, #0x1               ; =1
10016de4c:     	ldadd	x10, x10, [x24]
10016de50:     	tbnz	x10, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016de54:     	tst	x9, #0x70
10016de58:     	lsr	x9, x9, #7
10016de5c:     	cinc	x9, x9, ne
10016de60:     	str	x24, [sp, #0x2c0]
10016de64:     	str	x8, [sp, #0x2c8]
10016de68:     	str	x9, [sp, #0x2d0]
10016de6c:     	ldr	x8, [sp, #0x1a0]
10016de70:     	cmp	x8, #0x2
10016de74:     	b.eq	0x10016dd54 <_nera_rt_send_tuple+0xa18>
10016de78:     	b	0x10016dd60 <_nera_rt_send_tuple+0xa24>
10016de7c:     	cbnz	x9, 0x10016df50 <_nera_rt_send_tuple+0xc14>
10016de80:     	tst	x8, #0x7fffffffffffffff
10016de84:     	b.eq	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016de88:     	and	x8, x8, #0x7ffffffffffffff8
10016de8c:     	ldr	x8, [x8]
10016de90:     	and	x8, x8, #0xf
10016de94:     	cmp	x8, #0x6
10016de98:     	b.eq	0x10016da34 <_nera_rt_send_tuple+0x6f8>
10016de9c:     	b	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016dea0:     	cbnz	x9, 0x10016e08c <_nera_rt_send_tuple+0xd50>
10016dea4:     	tst	x8, #0x7fffffffffffffff
10016dea8:     	b.eq	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016deac:     	and	x8, x8, #0x7ffffffffffffff8
10016deb0:     	ldr	x8, [x8]
10016deb4:     	and	x8, x8, #0xf
10016deb8:     	cmp	x8, #0x6
10016debc:     	b.eq	0x10016d5b8 <_nera_rt_send_tuple+0x27c>
10016dec0:     	b	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016dec4:     	cbnz	x9, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016dec8:     	cbz	x8, 0x10016e3b4 <_nera_rt_send_tuple+0x1078>
10016decc:     	ldp	x9, x10, [x8]
10016ded0:     	ldr	x8, [x8, #0x10]
10016ded4:     	sub	x24, x10, #0x10
10016ded8:     	mov	w10, #0x1               ; =1
10016dedc:     	ldadd	x10, x10, [x24]
10016dee0:     	tbnz	x10, #0x3f, 0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016dee4:     	tst	x9, #0x70
10016dee8:     	lsr	x9, x9, #7
10016deec:     	cinc	x9, x9, ne
10016def0:     	str	x24, [sp, #0x2c0]
10016def4:     	str	x8, [sp, #0x2c8]
10016def8:     	str	x9, [sp, #0x2d0]
10016defc:     	ldr	x8, [sp, #0x1a0]
10016df00:     	cmp	x8, #0x3
10016df04:     	b.eq	0x10016ddb0 <_nera_rt_send_tuple+0xa74>
10016df08:     	b	0x10016ddbc <_nera_rt_send_tuple+0xa80>
10016df0c:     	cbnz	x9, 0x10016e118 <_nera_rt_send_tuple+0xddc>
10016df10:     	tst	x8, #0x7fffffffffffffff
10016df14:     	b.eq	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016df18:     	and	x8, x8, #0x7ffffffffffffff8
10016df1c:     	ldr	x8, [x8]
10016df20:     	and	x8, x8, #0xf
10016df24:     	cmp	x8, #0x6
10016df28:     	b.eq	0x10016d908 <_nera_rt_send_tuple+0x5cc>
10016df2c:     	b	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016df30:     	cbnz	x9, 0x10016df50 <_nera_rt_send_tuple+0xc14>
10016df34:     	tst	x8, #0x7fffffffffffffff
10016df38:     	b.eq	0x10016df50 <_nera_rt_send_tuple+0xc14>
10016df3c:     	and	x8, x8, #0x7ffffffffffffff8
10016df40:     	ldr	x8, [x8]
10016df44:     	and	x8, x8, #0xf
10016df48:     	cmp	x8, #0x6
10016df4c:     	b.eq	0x10016da50 <_nera_rt_send_tuple+0x714>
10016df50:     	add	x8, sp, #0x80
10016df54:     	mov	w0, #0x40               ; =64
10016df58:     	bl	0x10011bea4 <__RNvMs3_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB5_11ProcessHeap17new_with_capacity>
10016df5c:     	add	x23, x20, #0x1
10016df60:     	ldr	x9, [sp, #0x80]
10016df64:     	ldr	x8, [sp, #0x98]
10016df68:     	sub	x9, x9, x8
10016df6c:     	cmp	x20, x9
10016df70:     	b.hs	0x10016e37c <_nera_rt_send_tuple+0x1040>
10016df74:     	ldr	x9, [sp, #0x88]
10016df78:     	add	x24, x9, x8, lsl #3
10016df7c:     	add	x8, x8, x23
10016df80:     	str	x8, [sp, #0x98]
10016df84:     	lsl	x2, x20, #3
10016df88:     	ldr	x8, [sp, #0x150]
10016df8c:     	add	x8, x8, x23, lsl #3
10016df90:     	str	x8, [sp, #0x150]
10016df94:     	lsl	x8, x20, #4
10016df98:     	mov	x0, x24
10016df9c:     	str	x8, [x0], #0x8
10016dfa0:     	add	x1, sp, #0x10
10016dfa4:     	bl	0x100215254 <_writev+0x100215254>
10016dfa8:     	add	x8, sp, #0x2c0
10016dfac:     	mov	w0, #0x40               ; =64
10016dfb0:     	bl	0x10011bea4 <__RNvMs3_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB5_11ProcessHeap17new_with_capacity>
10016dfb4:     	add	x0, sp, #0x1a0
10016dfb8:     	add	x1, sp, #0x2c0
10016dfbc:     	mov	w2, #0x120              ; =288
10016dfc0:     	bl	0x100215254 <_writev+0x100215254>
10016dfc4:     	add	x1, sp, #0x1a0
10016dfc8:     	mov	x0, x24
10016dfcc:     	bl	0x10013bdec <__RNvNtCs3JpjsLPrFbG_12nera_runtime7message14deep_copy_term>
10016dfd0:     	mov	x20, x0
10016dfd4:     	add	x0, sp, #0x2c0
10016dfd8:     	add	x1, sp, #0x1a0
10016dfdc:     	mov	w2, #0x120              ; =288
10016dfe0:     	bl	0x100215254 <_writev+0x100215254>
10016dfe4:     	str	x20, [sp, #0x3e0]
10016dfe8:     	bl	0x100174620 <__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10016dfec:     	mov	w0, #0x128              ; =296
10016dff0:     	bl	0x100176fd0 <__rjem_malloc>
10016dff4:     	cbz	x0, 0x10016e390 <_nera_rt_send_tuple+0x1054>
10016dff8:     	mov	x20, x0
10016dffc:     	add	x1, sp, #0x2c0
10016e000:     	mov	w2, #0x128              ; =296
10016e004:     	bl	0x100215254 <_writev+0x100215254>
10016e008:     	str	x20, [sp, #0x50]
10016e00c:     	mov	w8, #0x1                ; =1
10016e010:     	str	w8, [sp, #0x48]
10016e014:     	add	x0, sp, #0x80
10016e018:     	bl	0x1000fb168 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCs3JpjsLPrFbG_12nera_runtime4heap11ProcessHeapEBF_>
10016e01c:     	add	x0, x19, #0x80
10016e020:     	add	x1, sp, #0x48
10016e024:     	bl	0x10011e100 <__RNvMs4_NtCsdK4Edh6vNBf_15crossbeam_queue9seg_queueINtB5_8SegQueueNtNtCs3JpjsLPrFbG_12nera_runtime7message15MessageFragmentE4pushB15_>
10016e028:     	add	x8, x19, #0x5a0
10016e02c:     	mov	w9, #0x2                ; =2
10016e030:     	casal	w9, wzr, [x8]
10016e034:     	cmp	w9, #0x2
10016e038:     	b.ne	0x10016e34c <_nera_rt_send_tuple+0x1010>
10016e03c:     	ldr	x8, [x27, #0x38]
10016e040:     	add	x8, x8, #0x10
10016e044:     	mov	w9, #0x1                ; =1
10016e048:     	ldaddal	x9, x8, [x8]
10016e04c:     	mov	x0, x27
10016e050:     	mov	x1, x19
10016e054:     	bl	0x10010bcb4 <__RNvMNtCs3JpjsLPrFbG_12nera_runtime9schedulerNtB2_15SchedulerHandle18dispatch_to_worker>
10016e058:     	ldr	x8, [x27, #0x50]
10016e05c:     	add	x0, x8, #0x10
10016e060:     	mov	x1, x26
10016e064:     	bl	0x10011a354 <__RNvMs2_NtCs3JpjsLPrFbG_12nera_runtime5timerNtB5_10TimerWheel14remove_for_pid>
10016e068:     	b	0x10016d69c <_nera_rt_send_tuple+0x360>
10016e06c:     	cbnz	x9, 0x10016e08c <_nera_rt_send_tuple+0xd50>
10016e070:     	tst	x8, #0x7fffffffffffffff
10016e074:     	b.eq	0x10016e08c <_nera_rt_send_tuple+0xd50>
10016e078:     	and	x8, x8, #0x7ffffffffffffff8
10016e07c:     	ldr	x8, [x8]
10016e080:     	and	x8, x8, #0xf
10016e084:     	cmp	x8, #0x6
10016e088:     	b.eq	0x10016d5d4 <_nera_rt_send_tuple+0x298>
10016e08c:     	add	x24, x20, #0x1
10016e090:     	ldr	x9, [x21]
10016e094:     	ldr	x8, [x21, #0x18]
10016e098:     	sub	x9, x9, x8
10016e09c:     	cmp	x20, x9
10016e0a0:     	b.hs	0x10016e3a0 <_nera_rt_send_tuple+0x1064>
10016e0a4:     	ldr	x9, [x21, #0x8]
10016e0a8:     	add	x22, x9, x8, lsl #3
10016e0ac:     	add	x8, x8, x24
10016e0b0:     	str	x8, [x21, #0x18]
10016e0b4:     	ldr	x8, [x21, #0xd0]
10016e0b8:     	add	x8, x8, x24, lsl #3
10016e0bc:     	str	x8, [x21, #0xd0]
10016e0c0:     	lsl	x8, x20, #4
10016e0c4:     	mov	x0, x22
10016e0c8:     	str	x8, [x0], #0x8
10016e0cc:     	add	x1, sp, #0x10
10016e0d0:     	mov	x2, x23
10016e0d4:     	bl	0x100215254 <_writev+0x100215254>
10016e0d8:     	mov	x0, x19
10016e0dc:     	mov	x1, x22
10016e0e0:     	bl	0x100124400 <__RNvMsc_NtCs3JpjsLPrFbG_12nera_runtime7processNtB5_7Mailbox4send>
10016e0e4:     	b	0x10016d69c <_nera_rt_send_tuple+0x360>
10016e0e8:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e0ec:     	add	x0, x0, #0x150
10016e0f0:     	bl	0x100214b40 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e0f4:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e0f8:     	cbnz	x9, 0x10016e118 <_nera_rt_send_tuple+0xddc>
10016e0fc:     	tst	x8, #0x7fffffffffffffff
10016e100:     	b.eq	0x10016e118 <_nera_rt_send_tuple+0xddc>
10016e104:     	and	x8, x8, #0x7ffffffffffffff8
10016e108:     	ldr	x8, [x8]
10016e10c:     	and	x8, x8, #0xf
10016e110:     	cmp	x8, #0x6
10016e114:     	b.eq	0x10016d924 <_nera_rt_send_tuple+0x5e8>
10016e118:     	add	x0, x19, #0x280
10016e11c:     	add	x2, sp, #0x10
10016e120:     	mov	x1, x20
10016e124:     	bl	0x1001fc754 <__RNvNtNtCs3JpjsLPrFbG_12nera_runtime3ffi7process18copy_complex_tuple>
10016e128:     	mov	x24, x0
10016e12c:     	b	0x10016e2ec <_nera_rt_send_tuple+0xfb0>
10016e130:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e134:     	add	x0, x0, #0x150
10016e138:     	bl	0x100214b40 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e13c:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e140:     	mov	x0, x19
10016e144:     	bl	0x10020e588 <__RNvMs8_NtCsexVl96cpVco_11parking_lot10raw_rwlockNtB5_9RawRwLock18unlock_shared_slow>
10016e148:     	b	0x10016d52c <_nera_rt_send_tuple+0x1f0>
10016e14c:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e150:     	add	x0, x0, #0x1b0
10016e154:     	bl	0x100214b40 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e158:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e15c:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e160:     	add	x3, x3, #0x1c8
10016e164:     	mov	x0, #0x0                ; =0
10016e168:     	mov	x1, x20
10016e16c:     	mov	w2, #0x4                ; =4
10016e170:     	bl	0x100214e38 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e174:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e178:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e17c:     	add	x3, x3, #0x168
10016e180:     	mov	x0, #0x0                ; =0
10016e184:     	mov	x1, x20
10016e188:     	mov	w2, #0x4                ; =4
10016e18c:     	bl	0x100214e38 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e190:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e194:     	cmp	w8, #0x1
10016e198:     	b.ne	0x10016e248 <_nera_rt_send_tuple+0xf0c>
10016e19c:     	adrp	x1, 0x1000ff000 <__RINvNtNtCs1SSuMAdGM58_3std3sys9backtrace28___rust_begin_short_backtraceNCNvNtCs3JpjsLPrFbG_12nera_runtime7reactor13spawn_reactor0uEB1d_+0xe50>
10016e1a0:     	add	x1, x1, #0xf8c
10016e1a4:     	mov	x0, x22
10016e1a8:     	bl	0x1001dbaac <__RNvNtNtNtNtCs1SSuMAdGM58_3std3sys12thread_local11destructors4list8register>
10016e1ac:     	strb	wzr, [x22, #0x18]
10016e1b0:     	ldr	x8, [x22]
10016e1b4:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10016e1b8:     	cmp	x8, x9
10016e1bc:     	b.lo	0x10016d6f8 <_nera_rt_send_tuple+0x3bc>
10016e1c0:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e1c4:     	add	x0, x0, #0x9f8
10016e1c8:     	bl	0x100214ac8 <__RNvNtCsjIpoRzUjyHQ_4core4cell30panic_already_mutably_borrowed>
10016e1cc:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e1d0:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e1d4:     	add	x3, x3, #0x168
10016e1d8:     	mov	x0, #0x0                ; =0
10016e1dc:     	mov	x1, x20
10016e1e0:     	mov	w2, #0x4                ; =4
10016e1e4:     	bl	0x100214e38 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e1e8:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e1ec:     	add	x1, x20, #0x1
10016e1f0:     	mov	x0, x24
10016e1f4:     	bl	0x1001fc5d0 <__RNvMs_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e1f8:     	mov	x22, x0
10016e1fc:     	ldr	x8, [x24, #0xd0]
10016e200:     	add	x8, x8, x21, lsl #3
10016e204:     	str	x8, [x24, #0xd0]
10016e208:     	lsr	x8, x20, #60
10016e20c:     	cbz	x8, 0x10016d844 <_nera_rt_send_tuple+0x508>
10016e210:     	adrp	x0, 0x100218000 <___nera_func_arities+0x628>
10016e214:     	add	x0, x0, #0x3ea
10016e218:     	adrp	x2, 0x100260000 <_writev+0x100260000>
10016e21c:     	add	x2, x2, #0x6c8
10016e220:     	mov	w1, #0x29               ; =41
10016e224:     	bl	0x100214b10 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
10016e228:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e22c:     	adrp	x3, 0x100260000 <_writev+0x100260000>
10016e230:     	add	x3, x3, #0xd28
10016e234:     	mov	x0, #0x0                ; =0
10016e238:     	mov	x1, x20
10016e23c:     	mov	w2, #0x4                ; =4
10016e240:     	bl	0x100214e38 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e244:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e248:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e24c:     	add	x0, x0, #0x580
10016e250:     	bl	0x1002142b8 <__RNvNtNtCs1SSuMAdGM58_3std6thread5local18panic_access_error>
10016e254:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e258:     	bl	0x10020c1d0 <__RNvMs0_NtCsaEawCaY6Xdf_7dashmap4lockNtB5_9RawRwLock18unlock_shared_slow>
10016e25c:     	b	0x10016d760 <_nera_rt_send_tuple+0x424>
10016e260:     	add	x20, sp, #0x2c0
10016e264:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e268:     	add	x0, x0, #0x9b0
10016e26c:     	bl	0x100214a98 <__RNvNtCsjIpoRzUjyHQ_4core4cell22panic_already_borrowed>
10016e270:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e274:     	add	x1, x20, #0x1
10016e278:     	mov	x0, x21
10016e27c:     	bl	0x1001fc5d0 <__RNvMs_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e280:     	mov	x22, x0
10016e284:     	ldr	x8, [x21, #0xd0]
10016e288:     	add	x8, x8, x24, lsl #3
10016e28c:     	str	x8, [x21, #0xd0]
10016e290:     	lsl	x8, x20, #4
10016e294:     	str	x8, [x0]
10016e298:     	cbnz	x20, 0x10016d614 <_nera_rt_send_tuple+0x2d8>
10016e29c:     	b	0x10016e0d8 <_nera_rt_send_tuple+0xd9c>
10016e2a0:     	cmp	w8, #0x2
10016e2a4:     	b.ne	0x10016e3c4 <_nera_rt_send_tuple+0x1088>
10016e2a8:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e2ac:     	add	x0, x0, #0x580
10016e2b0:     	bl	0x1002142b8 <__RNvNtNtCs1SSuMAdGM58_3std6thread5local18panic_access_error>
10016e2b4:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e2b8:     	add	x0, x19, #0x280
10016e2bc:     	add	x1, x20, #0x1
10016e2c0:     	bl	0x1001fc5d0 <__RNvMs_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e2c4:     	mov	x24, x0
10016e2c8:     	mov	x23, x26
10016e2cc:     	ldr	x8, [x19, #0x350]
10016e2d0:     	add	x8, x8, x21, lsl #3
10016e2d4:     	str	x8, [x19, #0x350]
10016e2d8:     	lsl	x8, x20, #4
10016e2dc:     	str	x8, [x0]
10016e2e0:     	cbnz	x20, 0x10016d96c <_nera_rt_send_tuple+0x630>
10016e2e4:     	mov	x26, x23
10016e2e8:     	ldr	x27, [sp, #0x8]
10016e2ec:     	add	x0, x19, #0x480
10016e2f0:     	mov	x1, x24
10016e2f4:     	bl	0x100124400 <__RNvMsc_NtCs3JpjsLPrFbG_12nera_runtime7processNtB5_7Mailbox4send>
10016e2f8:     	mov	w8, #0x1                ; =1
10016e2fc:     	caslb	w8, wzr, [x25]
10016e300:     	cmp	w8, #0x1
10016e304:     	b.ne	0x10016e36c <_nera_rt_send_tuple+0x1030>
10016e308:     	add	x8, x19, #0x5a0
10016e30c:     	mov	w9, #0x2                ; =2
10016e310:     	casal	w9, wzr, [x8]
10016e314:     	cmp	w9, #0x2
10016e318:     	b.ne	0x10016e34c <_nera_rt_send_tuple+0x1010>
10016e31c:     	ldr	x8, [x27, #0x38]
10016e320:     	add	x8, x8, #0x10
10016e324:     	mov	w9, #0x1                ; =1
10016e328:     	ldaddal	x9, x8, [x8]
10016e32c:     	mov	x0, x27
10016e330:     	mov	x1, x19
10016e334:     	bl	0x10010bcb4 <__RNvMNtCs3JpjsLPrFbG_12nera_runtime9schedulerNtB2_15SchedulerHandle18dispatch_to_worker>
10016e338:     	ldr	x8, [x27, #0x50]
10016e33c:     	add	x0, x8, #0x10
10016e340:     	mov	x1, x26
10016e344:     	bl	0x10011a354 <__RNvMs2_NtCs3JpjsLPrFbG_12nera_runtime5timerNtB5_10TimerWheel14remove_for_pid>
10016e348:     	b	0x10016d69c <_nera_rt_send_tuple+0x360>
10016e34c:     	mov	x8, #-0x1               ; =-1
10016e350:     	ldaddl	x8, x8, [x19]
10016e354:     	cmp	x8, #0x1
10016e358:     	b.ne	0x10016d69c <_nera_rt_send_tuple+0x360>
10016e35c:     	dmb	ishld
10016e360:     	add	x0, sp, #0x40
10016e364:     	bl	0x100125b40 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e368:     	b	0x10016d69c <_nera_rt_send_tuple+0x360>
10016e36c:     	add	x0, x19, #0x180
10016e370:     	mov	w1, #0x0                ; =0
10016e374:     	bl	0x10020d5a4 <__RNvMs1_NtCsexVl96cpVco_11parking_lot9raw_mutexNtB5_8RawMutex11unlock_slow>
10016e378:     	b	0x10016e308 <_nera_rt_send_tuple+0xfcc>
10016e37c:     	add	x0, sp, #0x80
10016e380:     	add	x1, x20, #0x1
10016e384:     	bl	0x1001fc5d0 <__RNvMs_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e388:     	mov	x24, x0
10016e38c:     	b	0x10016df84 <_nera_rt_send_tuple+0xc48>
10016e390:     	mov	w0, #0x8                ; =8
10016e394:     	mov	w1, #0x128              ; =296
10016e398:     	bl	0x100214978 <__RNvNtCs6zY7rJBZy9D_5alloc5alloc18handle_alloc_error>
10016e39c:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e3a0:     	add	x1, x20, #0x1
10016e3a4:     	mov	x0, x21
10016e3a8:     	bl	0x1001fc5d0 <__RNvMs_NtCs3JpjsLPrFbG_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e3ac:     	mov	x22, x0
10016e3b0:     	b	0x10016e0b4 <_nera_rt_send_tuple+0xd78>
10016e3b4:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e3b8:     	add	x0, x0, #0x198
10016e3bc:     	bl	0x100214b40 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e3c0:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e3c4:     	adrp	x1, 0x1000ff000 <__RINvNtNtCs1SSuMAdGM58_3std3sys9backtrace28___rust_begin_short_backtraceNCNvNtCs3JpjsLPrFbG_12nera_runtime7reactor13spawn_reactor0uEB1d_+0xe50>
10016e3c8:     	add	x1, x1, #0xf8c
10016e3cc:     	mov	x0, x22
10016e3d0:     	bl	0x1001dbaac <__RNvNtNtNtNtCs1SSuMAdGM58_3std3sys12thread_local11destructors4list8register>
10016e3d4:     	strb	wzr, [x22, #0x18]
10016e3d8:     	mov	w8, #0x1                ; =1
10016e3dc:     	ldadd	x8, x8, [x19]
10016e3e0:     	tbz	x8, #0x3f, 0x10016d778 <_nera_rt_send_tuple+0x43c>
10016e3e4:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e3e8:     	mov	w0, #0x8                ; =8
10016e3ec:     	mov	x1, x24
10016e3f0:     	bl	0x100214990 <__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error>
10016e3f4:     	b	0x10016db08 <_nera_rt_send_tuple+0x7cc>
10016e3f8:     	stp	x26, x19, [x22, #0x8]
10016e3fc:     	ldr	x8, [x22]
10016e400:     	add	x8, x8, #0x1
10016e404:     	str	x8, [x22]
10016e408:     	b	0x10016e4b8 <_nera_rt_send_tuple+0x117c>
10016e40c:     	add	x0, sp, #0x1a0
10016e410:     	bl	0x1000fb168 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCs3JpjsLPrFbG_12nera_runtime4heap11ProcessHeapEBF_>
10016e414:     	b	0x10016e488 <_nera_rt_send_tuple+0x114c>
10016e418:     	b	0x10016e488 <_nera_rt_send_tuple+0x114c>
10016e41c:     	cbz	x24, 0x10016e474 <_nera_rt_send_tuple+0x1138>
10016e420:     	mov	x8, #-0x1               ; =-1
10016e424:     	ldaddl	x8, x8, [x24]
10016e428:     	cmp	x8, #0x1
10016e42c:     	b.ne	0x10016e474 <_nera_rt_send_tuple+0x1138>
10016e430:     	dmb	ishld
10016e434:     	add	x0, sp, #0x2c0
10016e438:     	bl	0x1001259b8 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime6binary10BinaryDataE9drop_slowBK_>
10016e43c:     	b	0x10016e474 <_nera_rt_send_tuple+0x1138>
10016e440:     	mov	x8, #-0x10              ; =-16
10016e444:     	ldaddl	x8, x8, [x19]
10016e448:     	mov	x9, #-0xe               ; =-14
10016e44c:     	and	x8, x8, x9
10016e450:     	cmp	x8, #0x12
10016e454:     	b.ne	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e458:     	mov	x0, x19
10016e45c:     	bl	0x10020e588 <__RNvMs8_NtCsexVl96cpVco_11parking_lot10raw_rwlockNtB5_9RawRwLock18unlock_shared_slow>
10016e460:     	b	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e464:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e468:     	b	0x10016e50c <_nera_rt_send_tuple+0x11d0>
10016e46c:     	bl	0x100214d5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
10016e470:     	b	0x10016e4b8 <_nera_rt_send_tuple+0x117c>
10016e474:     	add	x0, sp, #0x1a0
10016e478:     	bl	0x1000f7250 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtCs6zY7rJBZy9D_5alloc3vec3VecNtNtCs3JpjsLPrFbG_12nera_runtime7message12FragmentElemEEB1c_>
10016e47c:     	b	0x10016e51c <_nera_rt_send_tuple+0x11e0>
10016e480:     	add	x0, sp, #0x2c0
10016e484:     	bl	0x1000fb168 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCs3JpjsLPrFbG_12nera_runtime4heap11ProcessHeapEBF_>
10016e488:     	add	x0, sp, #0x80
10016e48c:     	bl	0x1000fb168 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCs3JpjsLPrFbG_12nera_runtime4heap11ProcessHeapEBF_>
10016e490:     	b	0x10016e51c <_nera_rt_send_tuple+0x11e0>
10016e494:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e498:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e49c:     	mov	x8, #-0x1               ; =-1
10016e4a0:     	ldaddl	x8, x8, [x19]
10016e4a4:     	cmp	x8, #0x1
10016e4a8:     	b.ne	0x10016e4b8 <_nera_rt_send_tuple+0x117c>
10016e4ac:     	dmb	ishld
10016e4b0:     	add	x0, x20, #0x8
10016e4b4:     	bl	0x100125b40 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e4b8:     	mov	x8, #-0x1               ; =-1
10016e4bc:     	ldaddl	x8, x8, [x19]
10016e4c0:     	cmp	x8, #0x1
10016e4c4:     	b.ne	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e4c8:     	dmb	ishld
10016e4cc:     	add	x0, sp, #0x1a0
10016e4d0:     	bl	0x100125b40 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e4d4:     	b	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e4d8:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e4dc:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e4e0:     	cbz	x19, 0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e4e4:     	mov	x8, #-0x1               ; =-1
10016e4e8:     	ldaddl	x8, x8, [x19]
10016e4ec:     	cmp	x8, #0x1
10016e4f0:     	b.ne	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e4f4:     	add	x0, sp, #0x38
10016e4f8:     	b	0x10016e530 <_nera_rt_send_tuple+0x11f4>
10016e4fc:     	b	0x10016e51c <_nera_rt_send_tuple+0x11e0>
10016e500:     	add	x0, sp, #0x2c0
10016e504:     	bl	0x1000f5de8 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCs3JpjsLPrFbG_12nera_runtime7message12FragmentElemj2_EBG_>
10016e508:     	b	0x10016e51c <_nera_rt_send_tuple+0x11e0>
10016e50c:     	mov	w8, #0x1                ; =1
10016e510:     	caslb	w8, wzr, [x25]
10016e514:     	cmp	w8, #0x1
10016e518:     	b.ne	0x10016e53c <_nera_rt_send_tuple+0x1200>
10016e51c:     	mov	x8, #-0x1               ; =-1
10016e520:     	ldaddl	x8, x8, [x19]
10016e524:     	cmp	x8, #0x1
10016e528:     	b.ne	0x10016e538 <_nera_rt_send_tuple+0x11fc>
10016e52c:     	add	x0, sp, #0x40
10016e530:     	dmb	ishld
10016e534:     	bl	0x100125b40 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCs3JpjsLPrFbG_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e538:     	bl	0x100214d5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
10016e53c:     	add	x0, x19, #0x180
10016e540:     	mov	w1, #0x0                ; =0
10016e544:     	bl	0x10020d5a4 <__RNvMs1_NtCsexVl96cpVco_11parking_lot9raw_mutexNtB5_8RawMutex11unlock_slow>
10016e548:     	b	0x10016e51c <_nera_rt_send_tuple+0x11e0>
10016e54c:     	bl	0x100214c20 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e550:     	bl	0x100214d5c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
