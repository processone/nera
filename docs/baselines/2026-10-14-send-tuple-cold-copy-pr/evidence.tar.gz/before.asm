
/tmp/nera-tuple-publication/before-native/tuple2:	file format mach-o arm64

Disassembly of section __TEXT,__text:

000000010016d37c <_nera_rt_send_tuple>:
10016d37c:     	stp	x28, x27, [sp, #-0x60]!
10016d380:     	stp	x26, x25, [sp, #0x10]
10016d384:     	stp	x24, x23, [sp, #0x20]
10016d388:     	stp	x22, x21, [sp, #0x30]
10016d38c:     	stp	x20, x19, [sp, #0x40]
10016d390:     	stp	x29, x30, [sp, #0x50]
10016d394:     	add	x29, sp, #0x50
10016d398:     	sub	sp, sp, #0x400
10016d39c:     	mov	x28, x2
10016d3a0:     	mov	x24, x0
10016d3a4:     	stp	x3, x4, [sp, #0x10]
10016d3a8:     	stp	x5, x6, [sp, #0x20]
10016d3ac:     	and	x8, x1, #0x7
10016d3b0:     	cmp	x8, #0x3
10016d3b4:     	b.eq	0x10016d3d0 <_nera_rt_send_tuple+0x54>
10016d3b8:     	cmp	x8, #0x4
10016d3bc:     	b.ne	0x10016d430 <_nera_rt_send_tuple+0xb4>
10016d3c0:     	lsr	x21, x1, #3
10016d3c4:     	str	x21, [sp, #0x38]
10016d3c8:     	cbnz	x24, 0x10016d57c <_nera_rt_send_tuple+0x200>
10016d3cc:     	b	0x10016d6c8 <_nera_rt_send_tuple+0x34c>
10016d3d0:     	lsr	x21, x1, #3
10016d3d4:     	str	w21, [sp, #0x2c8]
10016d3d8:     	cbz	x24, 0x10016d3e4 <_nera_rt_send_tuple+0x68>
10016d3dc:     	ldr	x8, [x24, #0xb8]
10016d3e0:     	cbnz	x8, 0x10016d400 <_nera_rt_send_tuple+0x84>
10016d3e4:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d3e8:     	add	x8, x8, #0x3d8
10016d3ec:     	ldapr	x8, [x8]
10016d3f0:     	cbnz	x8, 0x10016d6d8 <_nera_rt_send_tuple+0x35c>
10016d3f4:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d3f8:     	ldr	x8, [x8, #0x3e0]
10016d3fc:     	add	x8, x8, #0x10
10016d400:     	ldr	x20, [x8, #0x48]
10016d404:     	add	x19, x20, #0x10
10016d408:     	ldr	x8, [x20, #0x10]
10016d40c:     	ubfx	x9, x8, #3, #1
10016d410:     	cmn	x8, #0x11
10016d414:     	csinc	w9, w9, wzr, ls
10016d418:     	tbz	w9, #0x0, 0x10016d458 <_nera_rt_send_tuple+0xdc>
10016d41c:     	add	x0, x20, #0x10
10016d420:     	mov	w1, #0x0                ; =0
10016d424:     	mov	w3, #-0x1               ; =-1
10016d428:     	bl	0x10020dd00 <__RNvMs8_NtCsiQUXO8wsxxS_11parking_lot10raw_rwlockNtB5_9RawRwLock16lock_shared_slow>
10016d42c:     	b	0x10016d46c <_nera_rt_send_tuple+0xf0>
10016d430:     	mov	x0, x24
10016d434:     	bl	0x10014ce54 <__RNvNtNtCsjjbGdudWbYv_12nera_runtime3ffi7helpers23capture_exception_trace>
10016d438:     	cbz	x24, 0x10016d6d8 <_nera_rt_send_tuple+0x35c>
10016d43c:     	mov	w8, #0x3                ; =3
10016d440:     	str	w8, [x24, #0x10]
10016d444:     	mov	w8, #0x33               ; =51
10016d448:     	str	x8, [x24, #0x18]
10016d44c:     	mov	w8, #0x1                ; =1
10016d450:     	str	w8, [x24, #0x3c]
10016d454:     	b	0x10016d6d8 <_nera_rt_send_tuple+0x35c>
10016d458:     	add	x9, x8, #0x10
10016d45c:     	mov	x10, x8
10016d460:     	casa	x10, x9, [x19]
10016d464:     	cmp	x10, x8
10016d468:     	b.ne	0x10016d41c <_nera_rt_send_tuple+0xa0>
10016d46c:     	ldr	x8, [x20, #0x30]
10016d470:     	cbz	x8, 0x10016d508 <_nera_rt_send_tuple+0x18c>
10016d474:     	ldp	x0, x1, [x20, #0x38]
10016d478:     	add	x2, sp, #0x2c8
10016d47c:     	bl	0x100104828 <__RINvYNtNtNtCs1SSuMAdGM58_3std4hash6random11RandomStateNtNtCsjIpoRzUjyHQ_4core4hash11BuildHasher8hash_oneRmECsjjbGdudWbYv_12nera_runtime>
10016d480:     	mov	x8, #0x0                ; =0
10016d484:     	lsr	x11, x0, #57
10016d488:     	ldp	x10, x9, [x20, #0x18]
10016d48c:     	dup.8b	v0, w11
10016d490:     	movi.2d	v1, #0xffffffffffffffff
10016d494:     	and	x11, x0, x9
10016d498:     	ldr	d2, [x10, x11]
10016d49c:     	cmeq.8b	v3, v2, v0
10016d4a0:     	fmov	x12, d3
10016d4a4:     	ands	x12, x12, #0x8080808080808080
10016d4a8:     	b.eq	0x10016d4d8 <_nera_rt_send_tuple+0x15c>
10016d4ac:     	rbit	x13, x12
10016d4b0:     	clz	x13, x13
10016d4b4:     	add	x13, x11, x13, lsr #3
10016d4b8:     	and	x13, x13, x9
10016d4bc:     	sub	x13, x10, x13, lsl #4
10016d4c0:     	ldur	w14, [x13, #-0x10]
10016d4c4:     	cmp	w14, w21
10016d4c8:     	b.eq	0x10016d54c <_nera_rt_send_tuple+0x1d0>
10016d4cc:     	sub	x13, x12, #0x2
10016d4d0:     	ands	x12, x13, x12
10016d4d4:     	b.ne	0x10016d4ac <_nera_rt_send_tuple+0x130>
10016d4d8:     	cmeq.8b	v2, v2, v1
10016d4dc:     	fmov	x12, d2
10016d4e0:     	cbnz	x12, 0x10016d508 <_nera_rt_send_tuple+0x18c>
10016d4e4:     	add	x8, x8, #0x8
10016d4e8:     	add	x0, x11, x8
10016d4ec:     	and	x11, x0, x9
10016d4f0:     	ldr	d2, [x10, x11]
10016d4f4:     	cmeq.8b	v3, v2, v0
10016d4f8:     	fmov	x12, d3
10016d4fc:     	ands	x12, x12, #0x8080808080808080
10016d500:     	b.ne	0x10016d4ac <_nera_rt_send_tuple+0x130>
10016d504:     	b	0x10016d4d8 <_nera_rt_send_tuple+0x15c>
10016d508:     	mov	x0, x24
10016d50c:     	bl	0x10014ce54 <__RNvNtNtCsjjbGdudWbYv_12nera_runtime3ffi7helpers23capture_exception_trace>
10016d510:     	mov	w20, #0x1               ; =1
10016d514:     	cbz	x24, 0x10016d52c <_nera_rt_send_tuple+0x1b0>
10016d518:     	mov	w8, #0x3                ; =3
10016d51c:     	str	w8, [x24, #0x10]
10016d520:     	mov	w8, #0x33               ; =51
10016d524:     	str	x8, [x24, #0x18]
10016d528:     	str	w20, [x24, #0x3c]
10016d52c:     	mov	w22, #0x5               ; =5
10016d530:     	mov	x8, #-0x10              ; =-16
10016d534:     	ldaddl	x8, x8, [x19]
10016d538:     	mov	x9, #-0xe               ; =-14
10016d53c:     	and	x8, x8, x9
10016d540:     	cmp	x8, #0x12
10016d544:     	b.ne	0x10016d56c <_nera_rt_send_tuple+0x1f0>
10016d548:     	b	0x10016e000 <_nera_rt_send_tuple+0xc84>
10016d54c:     	mov	w20, #0x0               ; =0
10016d550:     	ldur	x22, [x13, #-0x8]
10016d554:     	mov	x8, #-0x10              ; =-16
10016d558:     	ldaddl	x8, x8, [x19]
10016d55c:     	mov	x9, #-0xe               ; =-14
10016d560:     	and	x8, x8, x9
10016d564:     	cmp	x8, #0x12
10016d568:     	b.eq	0x10016e000 <_nera_rt_send_tuple+0xc84>
10016d56c:     	cbnz	w20, 0x10016d6dc <_nera_rt_send_tuple+0x360>
10016d570:     	str	x22, [sp, #0x38]
10016d574:     	mov	x21, x22
10016d578:     	cbz	x24, 0x10016d6c8 <_nera_rt_send_tuple+0x34c>
10016d57c:     	ldr	x8, [x24]
10016d580:     	cmp	x8, x21
10016d584:     	b.ne	0x10016d6c0 <_nera_rt_send_tuple+0x344>
10016d588:     	ldr	x21, [x24, #0x28]
10016d58c:     	mov	w22, #0x5               ; =5
10016d590:     	cbz	x21, 0x10016d6dc <_nera_rt_send_tuple+0x360>
10016d594:     	ldr	x19, [x24, #0x30]
10016d598:     	cbz	x19, 0x10016d6dc <_nera_rt_send_tuple+0x360>
10016d59c:     	cmp	x28, #0x5
10016d5a0:     	b.hs	0x10016e048 <_nera_rt_send_tuple+0xccc>
10016d5a4:     	lsl	x23, x28, #3
10016d5a8:     	cbz	x28, 0x10016d614 <_nera_rt_send_tuple+0x298>
10016d5ac:     	ldr	x8, [sp, #0x10]
10016d5b0:     	and	x9, x8, #0x7
10016d5b4:     	sub	x10, x9, #0x2
10016d5b8:     	cmp	x10, #0x4
10016d5bc:     	b.hs	0x10016dbb4 <_nera_rt_send_tuple+0x838>
10016d5c0:     	cmp	x28, #0x1
10016d5c4:     	b.eq	0x10016d614 <_nera_rt_send_tuple+0x298>
10016d5c8:     	ldr	x8, [sp, #0x18]
10016d5cc:     	and	x9, x8, #0x7
10016d5d0:     	sub	x10, x9, #0x2
10016d5d4:     	cmp	x10, #0x4
10016d5d8:     	b.hs	0x10016dd28 <_nera_rt_send_tuple+0x9ac>
10016d5dc:     	cmp	x28, #0x2
10016d5e0:     	b.eq	0x10016d614 <_nera_rt_send_tuple+0x298>
10016d5e4:     	ldr	x8, [sp, #0x20]
10016d5e8:     	and	x9, x8, #0x7
10016d5ec:     	sub	x10, x9, #0x2
10016d5f0:     	cmp	x10, #0x4
10016d5f4:     	b.hs	0x10016dd94 <_nera_rt_send_tuple+0xa18>
10016d5f8:     	cmp	x28, #0x3
10016d5fc:     	b.eq	0x10016d614 <_nera_rt_send_tuple+0x298>
10016d600:     	ldr	x8, [sp, #0x28]
10016d604:     	and	x9, x8, #0x7
10016d608:     	sub	x10, x9, #0x2
10016d60c:     	cmp	x10, #0x4
10016d610:     	b.hs	0x10016df18 <_nera_rt_send_tuple+0xb9c>
10016d614:     	add	x20, x28, #0x1
10016d618:     	ldr	x9, [x21]
10016d61c:     	ldr	x8, [x21, #0x18]
10016d620:     	sub	x9, x9, x8
10016d624:     	cmp	x28, x9
10016d628:     	b.hs	0x10016e144 <_nera_rt_send_tuple+0xdc8>
10016d62c:     	ldr	x9, [x21, #0x8]
10016d630:     	add	x22, x9, x8, lsl #3
10016d634:     	add	x8, x8, x20
10016d638:     	str	x8, [x21, #0x18]
10016d63c:     	ldr	x8, [x21, #0xd0]
10016d640:     	add	x8, x8, x20, lsl #3
10016d644:     	str	x8, [x21, #0xd0]
10016d648:     	lsl	x8, x28, #4
10016d64c:     	str	x8, [x22]
10016d650:     	cbz	x28, 0x10016df84 <_nera_rt_send_tuple+0xc08>
10016d654:     	add	x20, x22, #0x8
10016d658:     	add	x24, sp, #0x10
10016d65c:     	mov	w25, #0x1               ; =1
10016d660:     	b	0x10016d670 <_nera_rt_send_tuple+0x2f4>
10016d664:     	str	x0, [x20], #0x8
10016d668:     	subs	x23, x23, #0x8
10016d66c:     	b.eq	0x10016df84 <_nera_rt_send_tuple+0xc08>
10016d670:     	ldr	x8, [x24], #0x8
10016d674:     	and	x0, x8, #0x7fffffffffffffff
10016d678:     	and	x8, x8, #0x7
10016d67c:     	sub	x9, x8, #0x2
10016d680:     	cmp	x9, #0x4
10016d684:     	b.lo	0x10016d664 <_nera_rt_send_tuple+0x2e8>
10016d688:     	cmp	x8, #0x0
10016d68c:     	ccmp	x0, #0x0, #0x4, eq
10016d690:     	b.eq	0x10016df94 <_nera_rt_send_tuple+0xc18>
10016d694:     	ldp	x8, x9, [x0]
10016d698:     	ldr	x2, [x0, #0x10]
10016d69c:     	sub	x1, x9, #0x10
10016d6a0:     	ldadd	x25, x9, [x1]
10016d6a4:     	tbnz	x9, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016d6a8:     	tst	x8, #0x70
10016d6ac:     	lsr	x8, x8, #7
10016d6b0:     	cinc	x3, x8, ne
10016d6b4:     	mov	x0, x21
10016d6b8:     	bl	0x10011c340 <__RNvMs3_NtCsjjbGdudWbYv_12nera_runtime4heapNtB5_11ProcessHeap26alloc_refc_binary_from_arc>
10016d6bc:     	b	0x10016d664 <_nera_rt_send_tuple+0x2e8>
10016d6c0:     	ldr	x23, [x24, #0xb8]
10016d6c4:     	cbnz	x23, 0x10016d70c <_nera_rt_send_tuple+0x390>
10016d6c8:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d6cc:     	add	x8, x8, #0x3d8
10016d6d0:     	ldapr	x8, [x8]
10016d6d4:     	cbz	x8, 0x10016d700 <_nera_rt_send_tuple+0x384>
10016d6d8:     	mov	w22, #0x5               ; =5
10016d6dc:     	mov	x0, x22
10016d6e0:     	add	sp, sp, #0x400
10016d6e4:     	ldp	x29, x30, [sp, #0x50]
10016d6e8:     	ldp	x20, x19, [sp, #0x40]
10016d6ec:     	ldp	x22, x21, [sp, #0x30]
10016d6f0:     	ldp	x24, x23, [sp, #0x20]
10016d6f4:     	ldp	x26, x25, [sp, #0x10]
10016d6f8:     	ldp	x28, x27, [sp], #0x60
10016d6fc:     	ret
10016d700:     	adrp	x8, 0x10026d000 <___nera_atom_table+0x1000>
10016d704:     	ldr	x8, [x8, #0x3e0]
10016d708:     	add	x23, x8, #0x10
10016d70c:     	adrp	x0, 0x10026e000 <__rjem_je_tsd_boot_wrapper+0x608>
10016d710:     	add	x0, x0, #0xf30
10016d714:     	ldr	x8, [x0]
10016d718:     	blr	x8
10016d71c:     	mov	x22, x0
10016d720:     	ldrb	w8, [x0, #0x18]
10016d724:     	cbnz	w8, 0x10016e064 <_nera_rt_send_tuple+0xce8>
10016d728:     	ldr	x8, [x22]
10016d72c:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10016d730:     	cmp	x8, x9
10016d734:     	b.hs	0x10016e090 <_nera_rt_send_tuple+0xd14>
10016d738:     	add	x9, x8, #0x1
10016d73c:     	str	x9, [x22]
10016d740:     	mov	x25, x22
10016d744:     	ldr	x9, [x25, #0x10]!
10016d748:     	ldr	x10, [x22, #0x8]
10016d74c:     	cmp	x9, #0x0
10016d750:     	ccmp	x10, x21, #0x0, ne
10016d754:     	b.eq	0x10016d80c <_nera_rt_send_tuple+0x490>
10016d758:     	str	x8, [x22]
10016d75c:     	ldr	x8, [x23, #0x28]
10016d760:     	add	x0, sp, #0x2c8
10016d764:     	add	x1, x8, #0x10
10016d768:     	add	x2, sp, #0x38
10016d76c:     	bl	0x100103c18 <__RINvXs2_CsgIPviqa1FQE_7dashmapINtB6_7DashMapyINtNtCs6zY7rJBZy9D_5alloc4sync3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryEEINtNtB6_1t3MapyBH_NtNtNtCs1SSuMAdGM58_3std4hash6random11RandomStateE4__getyEB1j_>
10016d770:     	ldr	x0, [sp, #0x2c8]
10016d774:     	cbz	x0, 0x10016d834 <_nera_rt_send_tuple+0x4b8>
10016d778:     	ldr	x8, [sp, #0x2d8]
10016d77c:     	ldr	x9, [x8]
10016d780:     	mov	w10, #0x1               ; =1
10016d784:     	ldadd	x10, x9, [x9]
10016d788:     	tbnz	x9, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016d78c:     	ldr	x19, [x8]
10016d790:     	mov	x8, #-0x4               ; =-4
10016d794:     	ldaddl	x8, x8, [x0]
10016d798:     	cmp	x8, #0x6
10016d79c:     	b.eq	0x10016e128 <_nera_rt_send_tuple+0xdac>
10016d7a0:     	str	x19, [sp, #0x1a8]
10016d7a4:     	ldrb	w8, [x22, #0x18]
10016d7a8:     	cbnz	w8, 0x10016e170 <_nera_rt_send_tuple+0xdf4>
10016d7ac:     	mov	w8, #0x1                ; =1
10016d7b0:     	ldadd	x8, x8, [x19]
10016d7b4:     	tbnz	x8, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016d7b8:     	str	x21, [sp, #0x2c8]
10016d7bc:     	str	x19, [sp, #0x2d0]
10016d7c0:     	ldr	x8, [x22]
10016d7c4:     	cbnz	x8, 0x10016e130 <_nera_rt_send_tuple+0xdb4>
10016d7c8:     	mov	x8, #-0x1               ; =-1
10016d7cc:     	str	x8, [x22]
10016d7d0:     	ldr	x9, [x22, #0x10]
10016d7d4:     	cbz	x9, 0x10016d7f0 <_nera_rt_send_tuple+0x474>
10016d7d8:     	ldaddl	x8, x8, [x9]
10016d7dc:     	cmp	x8, #0x1
10016d7e0:     	b.ne	0x10016d7f0 <_nera_rt_send_tuple+0x474>
10016d7e4:     	dmb	ishld
10016d7e8:     	mov	x0, x25
10016d7ec:     	bl	0x100125bdc <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016d7f0:     	stp	x21, x19, [x22, #0x8]
10016d7f4:     	ldr	x8, [x22]
10016d7f8:     	add	x8, x8, #0x1
10016d7fc:     	str	x8, [x22]
10016d800:     	str	x19, [sp, #0x40]
10016d804:     	cbnz	x24, 0x10016d840 <_nera_rt_send_tuple+0x4c4>
10016d808:     	b	0x10016d8b0 <_nera_rt_send_tuple+0x534>
10016d80c:     	mov	w8, #0x1                ; =1
10016d810:     	ldadd	x8, x8, [x9]
10016d814:     	tbnz	x8, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016d818:     	ldr	x19, [x22, #0x10]
10016d81c:     	ldr	x8, [x22]
10016d820:     	sub	x8, x8, #0x1
10016d824:     	str	x8, [x22]
10016d828:     	str	x19, [sp, #0x40]
10016d82c:     	cbnz	x24, 0x10016d840 <_nera_rt_send_tuple+0x4c4>
10016d830:     	b	0x10016d8b0 <_nera_rt_send_tuple+0x534>
10016d834:     	mov	x19, #0x0               ; =0
10016d838:     	str	x19, [sp, #0x40]
10016d83c:     	cbz	x24, 0x10016d8b0 <_nera_rt_send_tuple+0x534>
10016d840:     	ldr	x24, [x24, #0x28]
10016d844:     	cbz	x24, 0x10016d8b0 <_nera_rt_send_tuple+0x534>
10016d848:     	add	x20, x28, #0x1
10016d84c:     	ldr	x9, [x24]
10016d850:     	ldr	x8, [x24, #0x18]
10016d854:     	sub	x9, x9, x8
10016d858:     	cmp	x20, x9
10016d85c:     	b.hi	0x10016e0bc <_nera_rt_send_tuple+0xd40>
10016d860:     	ldr	x9, [x24, #0x8]
10016d864:     	add	x22, x9, x8, lsl #3
10016d868:     	add	x8, x8, x20
10016d86c:     	str	x8, [x24, #0x18]
10016d870:     	ldr	x8, [x24, #0xd0]
10016d874:     	add	x8, x8, x20, lsl #3
10016d878:     	str	x8, [x24, #0xd0]
10016d87c:     	lsr	x8, x28, #60
10016d880:     	cbnz	x8, 0x10016e0e0 <_nera_rt_send_tuple+0xd64>
10016d884:     	lsl	x8, x28, #4
10016d888:     	str	x8, [x22]
10016d88c:     	cmp	x28, #0x5
10016d890:     	b.hs	0x10016e0fc <_nera_rt_send_tuple+0xd80>
10016d894:     	cbz	x28, 0x10016d8a8 <_nera_rt_send_tuple+0x52c>
10016d898:     	lsl	x2, x28, #3
10016d89c:     	add	x0, x22, #0x8
10016d8a0:     	add	x1, sp, #0x10
10016d8a4:     	bl	0x100215194 <_writev+0x100215194>
10016d8a8:     	cbnz	x19, 0x10016d8b8 <_nera_rt_send_tuple+0x53c>
10016d8ac:     	b	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016d8b0:     	mov	w22, #0x5               ; =5
10016d8b4:     	cbz	x19, 0x10016d6dc <_nera_rt_send_tuple+0x360>
10016d8b8:     	add	x26, sp, #0x2c8
10016d8bc:     	str	x19, [sp, #0x48]
10016d8c0:     	add	x8, x19, #0x5a0
10016d8c4:     	ldapr	w8, [x8]
10016d8c8:     	tst	w8, #0xfffffffd
10016d8cc:     	b.ne	0x10016da1c <_nera_rt_send_tuple+0x6a0>
10016d8d0:     	add	x25, x19, #0x180
10016d8d4:     	ldrb	w8, [x19, #0x180]
10016d8d8:     	tbnz	w8, #0x0, 0x10016da1c <_nera_rt_send_tuple+0x6a0>
10016d8dc:     	orr	w9, w8, #0x1
10016d8e0:     	mov	x10, x8
10016d8e4:     	casab	w10, w9, [x25]
10016d8e8:     	cmp	w10, w8, uxtb
10016d8ec:     	mov	x8, x10
10016d8f0:     	b.ne	0x10016d8d8 <_nera_rt_send_tuple+0x55c>
10016d8f4:     	cmp	x28, #0x5
10016d8f8:     	b.hs	0x10016e0a0 <_nera_rt_send_tuple+0xd24>
10016d8fc:     	cbz	x28, 0x10016d968 <_nera_rt_send_tuple+0x5ec>
10016d900:     	ldr	x8, [sp, #0x10]
10016d904:     	and	x9, x8, #0x7
10016d908:     	sub	x10, x9, #0x2
10016d90c:     	cmp	x10, #0x4
10016d910:     	b.hs	0x10016dce0 <_nera_rt_send_tuple+0x964>
10016d914:     	cmp	x28, #0x1
10016d918:     	b.eq	0x10016d968 <_nera_rt_send_tuple+0x5ec>
10016d91c:     	ldr	x8, [sp, #0x18]
10016d920:     	and	x9, x8, #0x7
10016d924:     	sub	x10, x9, #0x2
10016d928:     	cmp	x10, #0x4
10016d92c:     	b.hs	0x10016dd4c <_nera_rt_send_tuple+0x9d0>
10016d930:     	cmp	x28, #0x2
10016d934:     	b.eq	0x10016d968 <_nera_rt_send_tuple+0x5ec>
10016d938:     	ldr	x8, [sp, #0x20]
10016d93c:     	and	x9, x8, #0x7
10016d940:     	sub	x10, x9, #0x2
10016d944:     	cmp	x10, #0x4
10016d948:     	b.hs	0x10016ddb8 <_nera_rt_send_tuple+0xa3c>
10016d94c:     	cmp	x28, #0x3
10016d950:     	b.eq	0x10016d968 <_nera_rt_send_tuple+0x5ec>
10016d954:     	ldr	x8, [sp, #0x28]
10016d958:     	and	x9, x8, #0x7
10016d95c:     	sub	x10, x9, #0x2
10016d960:     	cmp	x10, #0x4
10016d964:     	b.hs	0x10016dfa4 <_nera_rt_send_tuple+0xc28>
10016d968:     	add	x20, x28, #0x1
10016d96c:     	ldr	x9, [x19, #0x280]
10016d970:     	ldr	x8, [x19, #0x298]
10016d974:     	sub	x9, x9, x8
10016d978:     	cmp	x28, x9
10016d97c:     	str	x23, [sp, #0x8]
10016d980:     	b.hs	0x10016e188 <_nera_rt_send_tuple+0xe0c>
10016d984:     	ldr	x9, [x19, #0x288]
10016d988:     	add	x24, x9, x8, lsl #3
10016d98c:     	add	x8, x8, x20
10016d990:     	str	x8, [x19, #0x298]
10016d994:     	ldr	x8, [x19, #0x350]
10016d998:     	add	x8, x8, x20, lsl #3
10016d99c:     	str	x8, [x19, #0x350]
10016d9a0:     	lsl	x8, x28, #4
10016d9a4:     	str	x8, [x24]
10016d9a8:     	cbz	x28, 0x10016e1b0 <_nera_rt_send_tuple+0xe34>
10016d9ac:     	lsl	x20, x28, #3
10016d9b0:     	add	x26, x24, #0x8
10016d9b4:     	add	x27, sp, #0x10
10016d9b8:     	mov	w23, #0x1               ; =1
10016d9bc:     	b	0x10016d9cc <_nera_rt_send_tuple+0x650>
10016d9c0:     	str	x0, [x26], #0x8
10016d9c4:     	subs	x20, x20, #0x8
10016d9c8:     	b.eq	0x10016e1b0 <_nera_rt_send_tuple+0xe34>
10016d9cc:     	ldr	x8, [x27], #0x8
10016d9d0:     	and	x0, x8, #0x7fffffffffffffff
10016d9d4:     	and	x8, x8, #0x7
10016d9d8:     	sub	x9, x8, #0x2
10016d9dc:     	cmp	x9, #0x4
10016d9e0:     	b.lo	0x10016d9c0 <_nera_rt_send_tuple+0x644>
10016d9e4:     	cmp	x8, #0x0
10016d9e8:     	ccmp	x0, #0x0, #0x4, eq
10016d9ec:     	b.eq	0x10016dff0 <_nera_rt_send_tuple+0xc74>
10016d9f0:     	ldp	x8, x9, [x0]
10016d9f4:     	ldr	x2, [x0, #0x10]
10016d9f8:     	sub	x1, x9, #0x10
10016d9fc:     	ldadd	x23, x9, [x1]
10016da00:     	tbnz	x9, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016da04:     	tst	x8, #0x70
10016da08:     	lsr	x8, x8, #7
10016da0c:     	cinc	x3, x8, ne
10016da10:     	add	x0, x19, #0x280
10016da14:     	bl	0x10011c340 <__RNvMs3_NtCsjjbGdudWbYv_12nera_runtime4heapNtB5_11ProcessHeap26alloc_refc_binary_from_arc>
10016da18:     	b	0x10016d9c0 <_nera_rt_send_tuple+0x644>
10016da1c:     	cmp	x28, #0x5
10016da20:     	b.hs	0x10016e02c <_nera_rt_send_tuple+0xcb0>
10016da24:     	cbz	x28, 0x10016db54 <_nera_rt_send_tuple+0x7d8>
10016da28:     	lsl	x24, x28, #3
10016da2c:     	ldr	x8, [sp, #0x10]
10016da30:     	and	x9, x8, #0x7
10016da34:     	sub	x10, x9, #0x2
10016da38:     	cmp	x10, #0x4
10016da3c:     	b.hs	0x10016db90 <_nera_rt_send_tuple+0x814>
10016da40:     	cmp	x28, #0x1
10016da44:     	b.eq	0x10016da94 <_nera_rt_send_tuple+0x718>
10016da48:     	ldr	x8, [sp, #0x18]
10016da4c:     	and	x9, x8, #0x7
10016da50:     	sub	x10, x9, #0x2
10016da54:     	cmp	x10, #0x4
10016da58:     	b.hs	0x10016dd04 <_nera_rt_send_tuple+0x988>
10016da5c:     	cmp	x28, #0x2
10016da60:     	b.eq	0x10016da94 <_nera_rt_send_tuple+0x718>
10016da64:     	ldr	x8, [sp, #0x20]
10016da68:     	and	x9, x8, #0x7
10016da6c:     	sub	x10, x9, #0x2
10016da70:     	cmp	x10, #0x4
10016da74:     	b.hs	0x10016dd70 <_nera_rt_send_tuple+0x9f4>
10016da78:     	cmp	x28, #0x3
10016da7c:     	b.eq	0x10016da94 <_nera_rt_send_tuple+0x718>
10016da80:     	ldr	x8, [sp, #0x28]
10016da84:     	and	x9, x8, #0x7
10016da88:     	sub	x10, x9, #0x2
10016da8c:     	cmp	x10, #0x4
10016da90:     	b.hs	0x10016dddc <_nera_rt_send_tuple+0xa60>
10016da94:     	cmp	x28, #0x3
10016da98:     	str	x23, [sp, #0x8]
10016da9c:     	b.hs	0x10016dbd8 <_nera_rt_send_tuple+0x85c>
10016daa0:     	mov	w8, #0x5                ; =5
10016daa4:     	str	xzr, [sp, #0x2c8]
10016daa8:     	str	x8, [sp, #0x2d0]
10016daac:     	add	x24, sp, #0x2c8
10016dab0:     	str	xzr, [sp, #0x2e0]
10016dab4:     	str	x8, [sp, #0x2e8]
10016dab8:     	add	x25, sp, #0x10
10016dabc:     	mov	x11, #-0x1              ; =-1
10016dac0:     	mov	x20, x28
10016dac4:     	b	0x10016dadc <_nera_rt_send_tuple+0x760>
10016dac8:     	stp	x27, x26, [x24]
10016dacc:     	str	x23, [x24, #0x10]
10016dad0:     	add	x24, x24, #0x18
10016dad4:     	subs	x20, x20, #0x1
10016dad8:     	b.eq	0x10016db6c <_nera_rt_send_tuple+0x7f0>
10016dadc:     	ldr	x8, [x25], #0x8
10016dae0:     	and	x26, x8, #0x7fffffffffffffff
10016dae4:     	and	x8, x8, #0x7
10016dae8:     	sub	x9, x8, #0x2
10016daec:     	cmp	x9, #0x4
10016daf0:     	b.hs	0x10016db20 <_nera_rt_send_tuple+0x7a4>
10016daf4:     	mov	x27, #0x0               ; =0
10016daf8:     	ldr	x8, [x24]
10016dafc:     	cbz	x8, 0x10016dac8 <_nera_rt_send_tuple+0x74c>
10016db00:     	ldaddl	x11, x8, [x8]
10016db04:     	cmp	x8, #0x1
10016db08:     	b.ne	0x10016dac8 <_nera_rt_send_tuple+0x74c>
10016db0c:     	dmb	ishld
10016db10:     	mov	x0, x24
10016db14:     	bl	0x100125a54 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime6binary10BinaryDataE9drop_slowBK_>
10016db18:     	mov	x11, #-0x1              ; =-1
10016db1c:     	b	0x10016dac8 <_nera_rt_send_tuple+0x74c>
10016db20:     	cmp	x8, #0x0
10016db24:     	ccmp	x26, #0x0, #0x4, eq
10016db28:     	b.eq	0x10016e00c <_nera_rt_send_tuple+0xc90>
10016db2c:     	ldp	x8, x9, [x26]
10016db30:     	lsr	x10, x8, #7
10016db34:     	tst	x8, #0x70
10016db38:     	cinc	x23, x10, ne
10016db3c:     	ldr	x26, [x26, #0x10]
10016db40:     	sub	x27, x9, #0x10
10016db44:     	mov	w8, #0x1                ; =1
10016db48:     	ldadd	x8, x8, [x27]
10016db4c:     	tbz	x8, #0x3f, 0x10016daf8 <_nera_rt_send_tuple+0x77c>
10016db50:     	brk	#0x1
10016db54:     	str	x23, [sp, #0x8]
10016db58:     	mov	w8, #0x5                ; =5
10016db5c:     	str	xzr, [sp, #0x2c8]
10016db60:     	str	x8, [sp, #0x2d0]
10016db64:     	str	xzr, [sp, #0x2e0]
10016db68:     	str	x8, [sp, #0x2e8]
10016db6c:     	add	x8, sp, #0x2c8
10016db70:     	ldp	q0, q1, [x8]
10016db74:     	stur	q0, [sp, #0x58]
10016db78:     	stur	q1, [sp, #0x68]
10016db7c:     	ldr	q0, [x8, #0x20]
10016db80:     	stur	q0, [sp, #0x78]
10016db84:     	mov	w8, #0x4                ; =4
10016db88:     	str	w28, [sp, #0x54]
10016db8c:     	b	0x10016dcd4 <_nera_rt_send_tuple+0x958>
10016db90:     	cbnz	x9, 0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016db94:     	tst	x8, #0x7fffffffffffffff
10016db98:     	b.eq	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016db9c:     	and	x8, x8, #0x7ffffffffffffff8
10016dba0:     	ldr	x8, [x8]
10016dba4:     	and	x8, x8, #0xf
10016dba8:     	cmp	x8, #0x6
10016dbac:     	b.eq	0x10016da40 <_nera_rt_send_tuple+0x6c4>
10016dbb0:     	b	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dbb4:     	cbnz	x9, 0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dbb8:     	tst	x8, #0x7fffffffffffffff
10016dbbc:     	b.eq	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dbc0:     	and	x8, x8, #0x7ffffffffffffff8
10016dbc4:     	ldr	x8, [x8]
10016dbc8:     	and	x8, x8, #0xf
10016dbcc:     	cmp	x8, #0x6
10016dbd0:     	b.eq	0x10016d5c0 <_nera_rt_send_tuple+0x244>
10016dbd4:     	b	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dbd8:     	add	x8, x28, x28, lsl #1
10016dbdc:     	lsl	x25, x8, #3
10016dbe0:     	bl	0x1001744d8 <__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10016dbe4:     	mov	x0, x25
10016dbe8:     	bl	0x100176e50 <__rjem_malloc>
10016dbec:     	cbz	x0, 0x10016e2a0 <_nera_rt_send_tuple+0xf24>
10016dbf0:     	mov	x25, #0x0               ; =0
10016dbf4:     	mov	x27, #0x0               ; =0
10016dbf8:     	stp	x28, x0, [sp, #0x1a8]
10016dbfc:     	add	x20, sp, #0x10
10016dc00:     	mov	w28, #0x1               ; =1
10016dc04:     	str	xzr, [sp, #0x1b8]
10016dc08:     	b	0x10016dc34 <_nera_rt_send_tuple+0x8b8>
10016dc0c:     	add	x8, x0, x25
10016dc10:     	ldr	q0, [x26]
10016dc14:     	ldr	x9, [sp, #0x2d8]
10016dc18:     	str	x9, [x8, #0x10]
10016dc1c:     	str	q0, [x8]
10016dc20:     	add	x27, x27, #0x1
10016dc24:     	str	x27, [sp, #0x1b8]
10016dc28:     	add	x25, x25, #0x18
10016dc2c:     	subs	x24, x24, #0x8
10016dc30:     	b.eq	0x10016dcbc <_nera_rt_send_tuple+0x940>
10016dc34:     	ldr	x9, [x20, x27, lsl #3]
10016dc38:     	and	x8, x9, #0x7fffffffffffffff
10016dc3c:     	and	x9, x9, #0x7
10016dc40:     	sub	x10, x9, #0x2
10016dc44:     	cmp	x10, #0x4
10016dc48:     	b.hs	0x10016dc74 <_nera_rt_send_tuple+0x8f8>
10016dc4c:     	mov	x23, #0x0               ; =0
10016dc50:     	str	x8, [sp, #0x2d0]
10016dc54:     	str	xzr, [sp, #0x2c8]
10016dc58:     	ldr	x8, [sp, #0x1a8]
10016dc5c:     	cmp	x27, x8
10016dc60:     	b.ne	0x10016dc0c <_nera_rt_send_tuple+0x890>
10016dc64:     	add	x0, sp, #0x1a8
10016dc68:     	bl	0x1001fae80 <__RNvMs4_NtCs6zY7rJBZy9D_5alloc7raw_vecINtB5_6RawVecTjjjEE8grow_oneCsjjbGdudWbYv_12nera_runtime>
10016dc6c:     	ldr	x0, [sp, #0x1b0]
10016dc70:     	b	0x10016dc0c <_nera_rt_send_tuple+0x890>
10016dc74:     	cmp	x9, #0x0
10016dc78:     	ccmp	x8, #0x0, #0x4, eq
10016dc7c:     	b.eq	0x10016e01c <_nera_rt_send_tuple+0xca0>
10016dc80:     	ldp	x9, x10, [x8]
10016dc84:     	ldr	x8, [x8, #0x10]
10016dc88:     	sub	x23, x10, #0x10
10016dc8c:     	ldadd	x28, x10, [x23]
10016dc90:     	tbnz	x10, #0x3f, 0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016dc94:     	tst	x9, #0x70
10016dc98:     	lsr	x9, x9, #7
10016dc9c:     	cinc	x9, x9, ne
10016dca0:     	str	x23, [sp, #0x2c8]
10016dca4:     	str	x8, [sp, #0x2d0]
10016dca8:     	str	x9, [sp, #0x2d8]
10016dcac:     	ldr	x8, [sp, #0x1a8]
10016dcb0:     	cmp	x27, x8
10016dcb4:     	b.ne	0x10016dc0c <_nera_rt_send_tuple+0x890>
10016dcb8:     	b	0x10016dc64 <_nera_rt_send_tuple+0x8e8>
10016dcbc:     	add	x8, sp, #0xa9
10016dcc0:     	ldur	q0, [x8, #0xff]
10016dcc4:     	stur	q0, [sp, #0x58]
10016dcc8:     	ldr	x8, [sp, #0x1b8]
10016dccc:     	str	x8, [sp, #0x68]
10016dcd0:     	mov	w8, #0x3                ; =3
10016dcd4:     	str	w8, [sp, #0x50]
10016dcd8:     	ldr	x23, [sp, #0x8]
10016dcdc:     	b	0x10016dec8 <_nera_rt_send_tuple+0xb4c>
10016dce0:     	cbnz	x9, 0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dce4:     	tst	x8, #0x7fffffffffffffff
10016dce8:     	b.eq	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dcec:     	and	x8, x8, #0x7ffffffffffffff8
10016dcf0:     	ldr	x8, [x8]
10016dcf4:     	and	x8, x8, #0xf
10016dcf8:     	cmp	x8, #0x6
10016dcfc:     	b.eq	0x10016d914 <_nera_rt_send_tuple+0x598>
10016dd00:     	b	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dd04:     	cbnz	x9, 0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd08:     	tst	x8, #0x7fffffffffffffff
10016dd0c:     	b.eq	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd10:     	and	x8, x8, #0x7ffffffffffffff8
10016dd14:     	ldr	x8, [x8]
10016dd18:     	and	x8, x8, #0xf
10016dd1c:     	cmp	x8, #0x6
10016dd20:     	b.eq	0x10016da5c <_nera_rt_send_tuple+0x6e0>
10016dd24:     	b	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd28:     	cbnz	x9, 0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dd2c:     	tst	x8, #0x7fffffffffffffff
10016dd30:     	b.eq	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dd34:     	and	x8, x8, #0x7ffffffffffffff8
10016dd38:     	ldr	x8, [x8]
10016dd3c:     	and	x8, x8, #0xf
10016dd40:     	cmp	x8, #0x6
10016dd44:     	b.eq	0x10016d5dc <_nera_rt_send_tuple+0x260>
10016dd48:     	b	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dd4c:     	cbnz	x9, 0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dd50:     	tst	x8, #0x7fffffffffffffff
10016dd54:     	b.eq	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dd58:     	and	x8, x8, #0x7ffffffffffffff8
10016dd5c:     	ldr	x8, [x8]
10016dd60:     	and	x8, x8, #0xf
10016dd64:     	cmp	x8, #0x6
10016dd68:     	b.eq	0x10016d930 <_nera_rt_send_tuple+0x5b4>
10016dd6c:     	b	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dd70:     	cbnz	x9, 0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd74:     	tst	x8, #0x7fffffffffffffff
10016dd78:     	b.eq	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd7c:     	and	x8, x8, #0x7ffffffffffffff8
10016dd80:     	ldr	x8, [x8]
10016dd84:     	and	x8, x8, #0xf
10016dd88:     	cmp	x8, #0x6
10016dd8c:     	b.eq	0x10016da78 <_nera_rt_send_tuple+0x6fc>
10016dd90:     	b	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dd94:     	cbnz	x9, 0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dd98:     	tst	x8, #0x7fffffffffffffff
10016dd9c:     	b.eq	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016dda0:     	and	x8, x8, #0x7ffffffffffffff8
10016dda4:     	ldr	x8, [x8]
10016dda8:     	and	x8, x8, #0xf
10016ddac:     	cmp	x8, #0x6
10016ddb0:     	b.eq	0x10016d5f8 <_nera_rt_send_tuple+0x27c>
10016ddb4:     	b	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016ddb8:     	cbnz	x9, 0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016ddbc:     	tst	x8, #0x7fffffffffffffff
10016ddc0:     	b.eq	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016ddc4:     	and	x8, x8, #0x7ffffffffffffff8
10016ddc8:     	ldr	x8, [x8]
10016ddcc:     	and	x8, x8, #0xf
10016ddd0:     	cmp	x8, #0x6
10016ddd4:     	b.eq	0x10016d94c <_nera_rt_send_tuple+0x5d0>
10016ddd8:     	b	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dddc:     	cbnz	x9, 0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dde0:     	tst	x8, #0x7fffffffffffffff
10016dde4:     	b.eq	0x10016ddfc <_nera_rt_send_tuple+0xa80>
10016dde8:     	and	x8, x8, #0x7ffffffffffffff8
10016ddec:     	ldr	x8, [x8]
10016ddf0:     	and	x8, x8, #0xf
10016ddf4:     	cmp	x8, #0x6
10016ddf8:     	b.eq	0x10016da94 <_nera_rt_send_tuple+0x718>
10016ddfc:     	add	x8, sp, #0x88
10016de00:     	mov	w0, #0x40               ; =64
10016de04:     	bl	0x10011bea4 <__RNvMs3_NtCsjjbGdudWbYv_12nera_runtime4heapNtB5_11ProcessHeap17new_with_capacity>
10016de08:     	add	x20, x28, #0x1
10016de0c:     	ldr	x9, [sp, #0x88]
10016de10:     	ldr	x8, [sp, #0xa0]
10016de14:     	sub	x9, x9, x8
10016de18:     	cmp	x28, x9
10016de1c:     	b.hs	0x10016e244 <_nera_rt_send_tuple+0xec8>
10016de20:     	ldr	x9, [sp, #0x90]
10016de24:     	add	x25, x9, x8, lsl #3
10016de28:     	add	x8, x8, x20
10016de2c:     	str	x8, [sp, #0xa0]
10016de30:     	ldr	x8, [sp, #0x158]
10016de34:     	add	x8, x8, x20, lsl #3
10016de38:     	str	x8, [sp, #0x158]
10016de3c:     	lsl	x8, x28, #4
10016de40:     	mov	x0, x25
10016de44:     	str	x8, [x0], #0x8
10016de48:     	add	x1, sp, #0x10
10016de4c:     	mov	x2, x24
10016de50:     	bl	0x100215194 <_writev+0x100215194>
10016de54:     	add	x8, sp, #0x2c8
10016de58:     	mov	w0, #0x40               ; =64
10016de5c:     	bl	0x10011bea4 <__RNvMs3_NtCsjjbGdudWbYv_12nera_runtime4heapNtB5_11ProcessHeap17new_with_capacity>
10016de60:     	add	x0, sp, #0x1a8
10016de64:     	add	x1, sp, #0x2c8
10016de68:     	mov	w2, #0x120              ; =288
10016de6c:     	bl	0x100215194 <_writev+0x100215194>
10016de70:     	add	x1, sp, #0x1a8
10016de74:     	mov	x0, x25
10016de78:     	bl	0x10013bf2c <__RNvNtCsjjbGdudWbYv_12nera_runtime7message14deep_copy_term>
10016de7c:     	mov	x20, x0
10016de80:     	add	x0, sp, #0x2c8
10016de84:     	add	x1, sp, #0x1a8
10016de88:     	mov	w2, #0x120              ; =288
10016de8c:     	bl	0x100215194 <_writev+0x100215194>
10016de90:     	str	x20, [sp, #0x3e8]
10016de94:     	bl	0x1001744d8 <__RNvCsdtSMxSA38aw_7___rustc35___rust_no_alloc_shim_is_unstable_v2>
10016de98:     	mov	w0, #0x128              ; =296
10016de9c:     	bl	0x100176e50 <__rjem_malloc>
10016dea0:     	cbz	x0, 0x10016e258 <_nera_rt_send_tuple+0xedc>
10016dea4:     	mov	x20, x0
10016dea8:     	add	x1, sp, #0x2c8
10016deac:     	mov	w2, #0x128              ; =296
10016deb0:     	bl	0x100215194 <_writev+0x100215194>
10016deb4:     	str	x20, [sp, #0x58]
10016deb8:     	mov	w8, #0x1                ; =1
10016debc:     	str	w8, [sp, #0x50]
10016dec0:     	add	x0, sp, #0x88
10016dec4:     	bl	0x1000fb1b0 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCsjjbGdudWbYv_12nera_runtime4heap11ProcessHeapEBF_>
10016dec8:     	add	x0, x19, #0x80
10016decc:     	add	x1, sp, #0x50
10016ded0:     	bl	0x10011da80 <__RNvMs4_NtCsdK4Edh6vNBf_15crossbeam_queue9seg_queueINtB5_8SegQueueNtNtCsjjbGdudWbYv_12nera_runtime7message15MessageFragmentE4pushB15_>
10016ded4:     	add	x8, x19, #0x5a0
10016ded8:     	mov	w9, #0x2                ; =2
10016dedc:     	casal	w9, wzr, [x8]
10016dee0:     	cmp	w9, #0x2
10016dee4:     	b.ne	0x10016e214 <_nera_rt_send_tuple+0xe98>
10016dee8:     	ldr	x8, [x23, #0x38]
10016deec:     	add	x8, x8, #0x10
10016def0:     	mov	w9, #0x1                ; =1
10016def4:     	ldaddal	x9, x8, [x8]
10016def8:     	mov	x0, x23
10016defc:     	mov	x1, x19
10016df00:     	bl	0x10010bfe0 <__RNvMNtCsjjbGdudWbYv_12nera_runtime9schedulerNtB2_15SchedulerHandle18dispatch_to_worker>
10016df04:     	ldr	x8, [x23, #0x50]
10016df08:     	add	x0, x8, #0x10
10016df0c:     	mov	x1, x21
10016df10:     	bl	0x10011a354 <__RNvMs2_NtCsjjbGdudWbYv_12nera_runtime5timerNtB5_10TimerWheel14remove_for_pid>
10016df14:     	b	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016df18:     	cbnz	x9, 0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016df1c:     	tst	x8, #0x7fffffffffffffff
10016df20:     	b.eq	0x10016df38 <_nera_rt_send_tuple+0xbbc>
10016df24:     	and	x8, x8, #0x7ffffffffffffff8
10016df28:     	ldr	x8, [x8]
10016df2c:     	and	x8, x8, #0xf
10016df30:     	cmp	x8, #0x6
10016df34:     	b.eq	0x10016d614 <_nera_rt_send_tuple+0x298>
10016df38:     	add	x20, x28, #0x1
10016df3c:     	ldr	x9, [x21]
10016df40:     	ldr	x8, [x21, #0x18]
10016df44:     	sub	x9, x9, x8
10016df48:     	cmp	x28, x9
10016df4c:     	b.hs	0x10016e268 <_nera_rt_send_tuple+0xeec>
10016df50:     	ldr	x9, [x21, #0x8]
10016df54:     	add	x22, x9, x8, lsl #3
10016df58:     	add	x8, x8, x20
10016df5c:     	str	x8, [x21, #0x18]
10016df60:     	ldr	x8, [x21, #0xd0]
10016df64:     	add	x8, x8, x20, lsl #3
10016df68:     	str	x8, [x21, #0xd0]
10016df6c:     	lsl	x8, x28, #4
10016df70:     	mov	x0, x22
10016df74:     	str	x8, [x0], #0x8
10016df78:     	add	x1, sp, #0x10
10016df7c:     	mov	x2, x23
10016df80:     	bl	0x100215194 <_writev+0x100215194>
10016df84:     	mov	x0, x19
10016df88:     	mov	x1, x22
10016df8c:     	bl	0x100124440 <__RNvMsc_NtCsjjbGdudWbYv_12nera_runtime7processNtB5_7Mailbox4send>
10016df90:     	b	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016df94:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016df98:     	add	x0, x0, #0x150
10016df9c:     	bl	0x100214a80 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016dfa0:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016dfa4:     	cbnz	x9, 0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dfa8:     	tst	x8, #0x7fffffffffffffff
10016dfac:     	b.eq	0x10016dfc4 <_nera_rt_send_tuple+0xc48>
10016dfb0:     	and	x8, x8, #0x7ffffffffffffff8
10016dfb4:     	ldr	x8, [x8]
10016dfb8:     	and	x8, x8, #0xf
10016dfbc:     	cmp	x8, #0x6
10016dfc0:     	b.eq	0x10016d968 <_nera_rt_send_tuple+0x5ec>
10016dfc4:     	lsl	x8, x28, #4
10016dfc8:     	str	x8, [sp, #0x2c8]
10016dfcc:     	ldp	q0, q1, [sp, #0x10]
10016dfd0:     	add	x8, sp, #0x2c8
10016dfd4:     	stur	q0, [x8, #0x8]
10016dfd8:     	stur	q1, [x8, #0x18]
10016dfdc:     	add	x0, sp, #0x2c8
10016dfe0:     	add	x1, x19, #0x280
10016dfe4:     	bl	0x10013bf2c <__RNvNtCsjjbGdudWbYv_12nera_runtime7message14deep_copy_term>
10016dfe8:     	mov	x24, x0
10016dfec:     	b	0x10016e1b4 <_nera_rt_send_tuple+0xe38>
10016dff0:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016dff4:     	add	x0, x0, #0x150
10016dff8:     	bl	0x100214a80 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016dffc:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e000:     	mov	x0, x19
10016e004:     	bl	0x10020e418 <__RNvMs8_NtCsiQUXO8wsxxS_11parking_lot10raw_rwlockNtB5_9RawRwLock18unlock_shared_slow>
10016e008:     	b	0x10016d56c <_nera_rt_send_tuple+0x1f0>
10016e00c:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e010:     	add	x0, x0, #0x198
10016e014:     	bl	0x100214a80 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e018:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e01c:     	adrp	x0, 0x100264000 <_writev+0x100264000>
10016e020:     	add	x0, x0, #0x180
10016e024:     	bl	0x100214a80 <__RNvNtCsjIpoRzUjyHQ_4core6option13unwrap_failed>
10016e028:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e02c:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e030:     	add	x3, x3, #0x1b0
10016e034:     	mov	x0, #0x0                ; =0
10016e038:     	mov	x1, x28
10016e03c:     	mov	w2, #0x4                ; =4
10016e040:     	bl	0x100214d78 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e044:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e048:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e04c:     	add	x3, x3, #0x168
10016e050:     	mov	x0, #0x0                ; =0
10016e054:     	mov	x1, x28
10016e058:     	mov	w2, #0x4                ; =4
10016e05c:     	bl	0x100214d78 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e060:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e064:     	cmp	w8, #0x1
10016e068:     	b.ne	0x10016e118 <_nera_rt_send_tuple+0xd9c>
10016e06c:     	adrp	x1, 0x1000ff000 <__RINvNtNtCs1SSuMAdGM58_3std3sys9backtrace28___rust_begin_short_backtraceNCNvNtCsjjbGdudWbYv_12nera_runtime7reactor13spawn_reactor0uEB1d_+0xe64>
10016e070:     	add	x1, x1, #0xf78
10016e074:     	mov	x0, x22
10016e078:     	bl	0x1001db9ec <__RNvNtNtNtNtCs1SSuMAdGM58_3std3sys12thread_local11destructors4list8register>
10016e07c:     	strb	wzr, [x22, #0x18]
10016e080:     	ldr	x8, [x22]
10016e084:     	mov	x9, #0x7fffffffffffffff ; =9223372036854775807
10016e088:     	cmp	x8, x9
10016e08c:     	b.lo	0x10016d738 <_nera_rt_send_tuple+0x3bc>
10016e090:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e094:     	add	x0, x0, #0x9e0
10016e098:     	bl	0x100214a08 <__RNvNtCsjIpoRzUjyHQ_4core4cell30panic_already_mutably_borrowed>
10016e09c:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e0a0:     	adrp	x3, 0x100264000 <_writev+0x100264000>
10016e0a4:     	add	x3, x3, #0x168
10016e0a8:     	mov	x0, #0x0                ; =0
10016e0ac:     	mov	x1, x28
10016e0b0:     	mov	w2, #0x4                ; =4
10016e0b4:     	bl	0x100214d78 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e0b8:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e0bc:     	add	x1, x28, #0x1
10016e0c0:     	mov	x0, x24
10016e0c4:     	bl	0x1001fc450 <__RNvMs_NtCsjjbGdudWbYv_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e0c8:     	mov	x22, x0
10016e0cc:     	ldr	x8, [x24, #0xd0]
10016e0d0:     	add	x8, x8, x20, lsl #3
10016e0d4:     	str	x8, [x24, #0xd0]
10016e0d8:     	lsr	x8, x28, #60
10016e0dc:     	cbz	x8, 0x10016d884 <_nera_rt_send_tuple+0x508>
10016e0e0:     	adrp	x0, 0x100218000 <___nera_func_arities+0x6e8>
10016e0e4:     	add	x0, x0, #0x343
10016e0e8:     	adrp	x2, 0x100260000 <_writev+0x100260000>
10016e0ec:     	add	x2, x2, #0x6e0
10016e0f0:     	mov	w1, #0x29               ; =41
10016e0f4:     	bl	0x100214a50 <__RNvNtCsjIpoRzUjyHQ_4core6option13expect_failed>
10016e0f8:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e0fc:     	adrp	x3, 0x100260000 <_writev+0x100260000>
10016e100:     	add	x3, x3, #0xd10
10016e104:     	mov	x0, #0x0                ; =0
10016e108:     	mov	x1, x28
10016e10c:     	mov	w2, #0x4                ; =4
10016e110:     	bl	0x100214d78 <__RNvNtNtCsjIpoRzUjyHQ_4core5slice5index16slice_index_fail>
10016e114:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e118:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e11c:     	add	x0, x0, #0x580
10016e120:     	bl	0x1002141f8 <__RNvNtNtCs1SSuMAdGM58_3std6thread5local18panic_access_error>
10016e124:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e128:     	bl	0x10020bfd0 <__RNvMs0_NtCsgIPviqa1FQE_7dashmap4lockNtB5_9RawRwLock18unlock_shared_slow>
10016e12c:     	b	0x10016d7a0 <_nera_rt_send_tuple+0x424>
10016e130:     	add	x20, sp, #0x2c8
10016e134:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e138:     	add	x0, x0, #0x998
10016e13c:     	bl	0x1002149d8 <__RNvNtCsjIpoRzUjyHQ_4core4cell22panic_already_borrowed>
10016e140:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e144:     	add	x1, x28, #0x1
10016e148:     	mov	x0, x21
10016e14c:     	bl	0x1001fc450 <__RNvMs_NtCsjjbGdudWbYv_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e150:     	mov	x22, x0
10016e154:     	ldr	x8, [x21, #0xd0]
10016e158:     	add	x8, x8, x20, lsl #3
10016e15c:     	str	x8, [x21, #0xd0]
10016e160:     	lsl	x8, x28, #4
10016e164:     	str	x8, [x0]
10016e168:     	cbnz	x28, 0x10016d654 <_nera_rt_send_tuple+0x2d8>
10016e16c:     	b	0x10016df84 <_nera_rt_send_tuple+0xc08>
10016e170:     	cmp	w8, #0x2
10016e174:     	b.ne	0x10016e27c <_nera_rt_send_tuple+0xf00>
10016e178:     	adrp	x0, 0x100260000 <_writev+0x100260000>
10016e17c:     	add	x0, x0, #0x580
10016e180:     	bl	0x1002141f8 <__RNvNtNtCs1SSuMAdGM58_3std6thread5local18panic_access_error>
10016e184:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e188:     	add	x0, x19, #0x280
10016e18c:     	add	x1, x28, #0x1
10016e190:     	bl	0x1001fc450 <__RNvMs_NtCsjjbGdudWbYv_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e194:     	mov	x24, x0
10016e198:     	ldr	x8, [x19, #0x350]
10016e19c:     	add	x8, x8, x20, lsl #3
10016e1a0:     	str	x8, [x19, #0x350]
10016e1a4:     	lsl	x8, x28, #4
10016e1a8:     	str	x8, [x0]
10016e1ac:     	cbnz	x28, 0x10016d9ac <_nera_rt_send_tuple+0x630>
10016e1b0:     	ldr	x23, [sp, #0x8]
10016e1b4:     	add	x0, x19, #0x480
10016e1b8:     	mov	x1, x24
10016e1bc:     	bl	0x100124440 <__RNvMsc_NtCsjjbGdudWbYv_12nera_runtime7processNtB5_7Mailbox4send>
10016e1c0:     	mov	w8, #0x1                ; =1
10016e1c4:     	caslb	w8, wzr, [x25]
10016e1c8:     	cmp	w8, #0x1
10016e1cc:     	b.ne	0x10016e234 <_nera_rt_send_tuple+0xeb8>
10016e1d0:     	add	x8, x19, #0x5a0
10016e1d4:     	mov	w9, #0x2                ; =2
10016e1d8:     	casal	w9, wzr, [x8]
10016e1dc:     	cmp	w9, #0x2
10016e1e0:     	b.ne	0x10016e214 <_nera_rt_send_tuple+0xe98>
10016e1e4:     	ldr	x8, [x23, #0x38]
10016e1e8:     	add	x8, x8, #0x10
10016e1ec:     	mov	w9, #0x1                ; =1
10016e1f0:     	ldaddal	x9, x8, [x8]
10016e1f4:     	mov	x0, x23
10016e1f8:     	mov	x1, x19
10016e1fc:     	bl	0x10010bfe0 <__RNvMNtCsjjbGdudWbYv_12nera_runtime9schedulerNtB2_15SchedulerHandle18dispatch_to_worker>
10016e200:     	ldr	x8, [x23, #0x50]
10016e204:     	add	x0, x8, #0x10
10016e208:     	mov	x1, x21
10016e20c:     	bl	0x10011a354 <__RNvMs2_NtCsjjbGdudWbYv_12nera_runtime5timerNtB5_10TimerWheel14remove_for_pid>
10016e210:     	b	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016e214:     	mov	x8, #-0x1               ; =-1
10016e218:     	ldaddl	x8, x8, [x19]
10016e21c:     	cmp	x8, #0x1
10016e220:     	b.ne	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016e224:     	dmb	ishld
10016e228:     	add	x0, sp, #0x48
10016e22c:     	bl	0x100125bdc <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e230:     	b	0x10016d6dc <_nera_rt_send_tuple+0x360>
10016e234:     	add	x0, x19, #0x180
10016e238:     	mov	w1, #0x0                ; =0
10016e23c:     	bl	0x10020d424 <__RNvMs1_NtCsiQUXO8wsxxS_11parking_lot9raw_mutexNtB5_8RawMutex11unlock_slow>
10016e240:     	b	0x10016e1d0 <_nera_rt_send_tuple+0xe54>
10016e244:     	add	x0, sp, #0x88
10016e248:     	add	x1, x28, #0x1
10016e24c:     	bl	0x1001fc450 <__RNvMs_NtCsjjbGdudWbYv_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e250:     	mov	x25, x0
10016e254:     	b	0x10016de30 <_nera_rt_send_tuple+0xab4>
10016e258:     	mov	w0, #0x8                ; =8
10016e25c:     	mov	w1, #0x128              ; =296
10016e260:     	bl	0x1002148b8 <__RNvNtCs6zY7rJBZy9D_5alloc5alloc18handle_alloc_error>
10016e264:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e268:     	add	x1, x28, #0x1
10016e26c:     	mov	x0, x21
10016e270:     	bl	0x1001fc450 <__RNvMs_NtCsjjbGdudWbYv_12nera_runtime4heapNtB4_8YoungGen14grow_and_alloc>
10016e274:     	mov	x22, x0
10016e278:     	b	0x10016df60 <_nera_rt_send_tuple+0xbe4>
10016e27c:     	adrp	x1, 0x1000ff000 <__RINvNtNtCs1SSuMAdGM58_3std3sys9backtrace28___rust_begin_short_backtraceNCNvNtCsjjbGdudWbYv_12nera_runtime7reactor13spawn_reactor0uEB1d_+0xe64>
10016e280:     	add	x1, x1, #0xf78
10016e284:     	mov	x0, x22
10016e288:     	bl	0x1001db9ec <__RNvNtNtNtNtCs1SSuMAdGM58_3std3sys12thread_local11destructors4list8register>
10016e28c:     	strb	wzr, [x22, #0x18]
10016e290:     	mov	w8, #0x1                ; =1
10016e294:     	ldadd	x8, x8, [x19]
10016e298:     	tbz	x8, #0x3f, 0x10016d7b8 <_nera_rt_send_tuple+0x43c>
10016e29c:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e2a0:     	mov	w0, #0x8                ; =8
10016e2a4:     	mov	x1, x25
10016e2a8:     	bl	0x1002148d0 <__RNvNtCs6zY7rJBZy9D_5alloc7raw_vec12handle_error>
10016e2ac:     	b	0x10016db50 <_nera_rt_send_tuple+0x7d4>
10016e2b0:     	stp	x21, x19, [x22, #0x8]
10016e2b4:     	ldr	x8, [x22]
10016e2b8:     	add	x8, x8, #0x1
10016e2bc:     	str	x8, [x22]
10016e2c0:     	b	0x10016e364 <_nera_rt_send_tuple+0xfe8>
10016e2c4:     	add	x0, sp, #0x1a8
10016e2c8:     	bl	0x1000fb1b0 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCsjjbGdudWbYv_12nera_runtime4heap11ProcessHeapEBF_>
10016e2cc:     	b	0x10016e334 <_nera_rt_send_tuple+0xfb8>
10016e2d0:     	b	0x10016e334 <_nera_rt_send_tuple+0xfb8>
10016e2d4:     	mov	x8, #-0x10              ; =-16
10016e2d8:     	ldaddl	x8, x8, [x19]
10016e2dc:     	mov	x9, #-0xe               ; =-14
10016e2e0:     	and	x8, x8, x9
10016e2e4:     	cmp	x8, #0x12
10016e2e8:     	b.ne	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e2ec:     	mov	x0, x19
10016e2f0:     	bl	0x10020e418 <__RNvMs8_NtCsiQUXO8wsxxS_11parking_lot10raw_rwlockNtB5_9RawRwLock18unlock_shared_slow>
10016e2f4:     	b	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e2f8:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e2fc:     	cbz	x23, 0x10016e3ac <_nera_rt_send_tuple+0x1030>
10016e300:     	mov	x8, #-0x1               ; =-1
10016e304:     	ldaddl	x8, x8, [x23]
10016e308:     	cmp	x8, #0x1
10016e30c:     	b.ne	0x10016e3ac <_nera_rt_send_tuple+0x1030>
10016e310:     	dmb	ishld
10016e314:     	add	x0, sp, #0x2c8
10016e318:     	bl	0x100125a54 <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime6binary10BinaryDataE9drop_slowBK_>
10016e31c:     	b	0x10016e3ac <_nera_rt_send_tuple+0x1030>
10016e320:     	b	0x10016e3c4 <_nera_rt_send_tuple+0x1048>
10016e324:     	bl	0x100214c9c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
10016e328:     	b	0x10016e364 <_nera_rt_send_tuple+0xfe8>
10016e32c:     	add	x0, sp, #0x2c8
10016e330:     	bl	0x1000fb1b0 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCsjjbGdudWbYv_12nera_runtime4heap11ProcessHeapEBF_>
10016e334:     	add	x0, sp, #0x88
10016e338:     	bl	0x1000fb1b0 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueNtNtCsjjbGdudWbYv_12nera_runtime4heap11ProcessHeapEBF_>
10016e33c:     	b	0x10016e3d4 <_nera_rt_send_tuple+0x1058>
10016e340:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e344:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e348:     	mov	x8, #-0x1               ; =-1
10016e34c:     	ldaddl	x8, x8, [x19]
10016e350:     	cmp	x8, #0x1
10016e354:     	b.ne	0x10016e364 <_nera_rt_send_tuple+0xfe8>
10016e358:     	dmb	ishld
10016e35c:     	add	x0, x20, #0x8
10016e360:     	bl	0x100125bdc <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e364:     	mov	x8, #-0x1               ; =-1
10016e368:     	ldaddl	x8, x8, [x19]
10016e36c:     	cmp	x8, #0x1
10016e370:     	b.ne	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e374:     	dmb	ishld
10016e378:     	add	x0, sp, #0x1a8
10016e37c:     	bl	0x100125bdc <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e380:     	b	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e384:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e388:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e38c:     	cbz	x19, 0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e390:     	mov	x8, #-0x1               ; =-1
10016e394:     	ldaddl	x8, x8, [x19]
10016e398:     	cmp	x8, #0x1
10016e39c:     	b.ne	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e3a0:     	add	x0, sp, #0x40
10016e3a4:     	b	0x10016e3e8 <_nera_rt_send_tuple+0x106c>
10016e3a8:     	b	0x10016e3d4 <_nera_rt_send_tuple+0x1058>
10016e3ac:     	add	x0, sp, #0x1a8
10016e3b0:     	bl	0x1000f71c8 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueINtNtCs6zY7rJBZy9D_5alloc3vec3VecNtNtCsjjbGdudWbYv_12nera_runtime7message12FragmentElemEEB1c_>
10016e3b4:     	b	0x10016e3d4 <_nera_rt_send_tuple+0x1058>
10016e3b8:     	add	x0, sp, #0x2c8
10016e3bc:     	bl	0x1000f5dd4 <__RINvNtCsjIpoRzUjyHQ_4core3ptr9drop_glueANtNtCsjjbGdudWbYv_12nera_runtime7message12FragmentElemj2_EBG_>
10016e3c0:     	b	0x10016e3d4 <_nera_rt_send_tuple+0x1058>
10016e3c4:     	mov	w8, #0x1                ; =1
10016e3c8:     	caslb	w8, wzr, [x25]
10016e3cc:     	cmp	w8, #0x1
10016e3d0:     	b.ne	0x10016e3f4 <_nera_rt_send_tuple+0x1078>
10016e3d4:     	mov	x8, #-0x1               ; =-1
10016e3d8:     	ldaddl	x8, x8, [x19]
10016e3dc:     	cmp	x8, #0x1
10016e3e0:     	b.ne	0x10016e3f0 <_nera_rt_send_tuple+0x1074>
10016e3e4:     	add	x0, sp, #0x48
10016e3e8:     	dmb	ishld
10016e3ec:     	bl	0x100125bdc <__RNvMsn_NtCs6zY7rJBZy9D_5alloc4syncINtB5_3ArcNtNtCsjjbGdudWbYv_12nera_runtime7process12ProcessEntryE9drop_slowBK_>
10016e3f0:     	bl	0x100214c9c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
10016e3f4:     	add	x0, x19, #0x180
10016e3f8:     	mov	w1, #0x0                ; =0
10016e3fc:     	bl	0x10020d424 <__RNvMs1_NtCsiQUXO8wsxxS_11parking_lot9raw_mutexNtB5_8RawMutex11unlock_slow>
10016e400:     	b	0x10016e3d4 <_nera_rt_send_tuple+0x1058>
10016e404:     	bl	0x100214b60 <__RNvNtCsjIpoRzUjyHQ_4core9panicking16panic_in_cleanup>
10016e408:     	bl	0x100214c9c <__RNvNtCsjIpoRzUjyHQ_4core9panicking19panic_cannot_unwind>
